package com.example.ex_4;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class RankActivity extends AppCompatActivity {

    private ImageButton Ibtn_rerank, Ibtn_BK;

    private String ogurl,id;
    private LinearLayout toplayout;

    String input = "";
    private ListView listview;

    DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("userinfo");
    List<Map<String, Object>> items = new ArrayList<Map<String, Object>>();
    public StorageReference storage = FirebaseStorage.getInstance().getReference();
    String[] dataname = {"image", "rank", "name", "message"};
    int[] view_address = {R.id.imageViewno1, R.id.no1text, R.id.textViewno1, R.id.textViewno12};

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rank);

        SharedPreferences sharedPreferences = getSharedPreferences("my_prefs", Context.MODE_PRIVATE);
        ogurl = sharedPreferences.getString("url","");
        listview = (ListView) findViewById(R.id.listview);

        Ibtn_BK = (ImageButton) findViewById(R.id.imagebtn_back);
        Ibtn_rerank = (ImageButton) findViewById(R.id.imagebtn_reload);
        Ibtn_rerank.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gettop10();
//                String url = geturl("gettop10rank", new String[]{});
//                System.out.println(url);
//                StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
//                    @Override
//                    public void onResponse(String response) {
//                        String[] parts = response.split("&");
//                        reloaddata(parts);
//                    }
//                }, new Response.ErrorListener() {
//                    @Override
//                    public void onErrorResponse(VolleyError error) {
//                        System.out.println("========排行出問題=========");
//                    }
//
//                });
//
//                RequestQueue queue = Volley.newRequestQueue(RankActivity.this);
//                queue.add(stringRequest);
            }
        });
        Ibtn_rerank.setBackgroundColor(Color.TRANSPARENT);
        toplayout = (LinearLayout) findViewById(R.id.toplayout);
        Ibtn_BK.setBackgroundColor(Color.TRANSPARENT);
        Ibtn_BK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        //滾到最後一個項目啟動重整(但會造成不必要的重新讀取畫面)
//        listview.setOnScrollListener(new AbsListView.OnScrollListener() {
//            @Override
//            public void onScrollStateChanged(AbsListView view, int scrollState) {
//                // 不需要實現
//            }
//
//            @Override
//            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
//                if (firstVisibleItem + visibleItemCount == totalItemCount && totalItemCount != 0) {
//                    // 滾動到最後一個 item，加載數據
//                    reloaddata();
//                }
//            }
//        });
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // 在這裡處理項目的選擇事件
                HashMap<String, Object> item = (HashMap<String, Object>) parent.getItemAtPosition(position);
                String name = (String) item.get("name");
                String rank = (String) item.get("rank");
                String msg = (String) item.get("message");
                File image = (File) item.get("image");
                Dialog myBuilder = new Dialog(RankActivity.this){
                    @Override
                    public void onCreate(Bundle savedInstanceState) {
                        super.onCreate(savedInstanceState);

                        // 設置Dialog的內容視圖
                        setContentView(R.layout.rankdetail_dialog_layout);

                        ImageView IV_head = findViewById(R.id.IV_head);
                        TextView TV_rank_rank = findViewById(R.id.TV_rankdetail_rank);
                        TV_rank_rank.setText(rank.substring(0,4));
                        TextView TV_rank_name = findViewById(R.id.TV_rankdetail_name);
                        TV_rank_name.setText(name);
                        TextView TV_rank_score = findViewById(R.id.TV_rankdetail_score);
                        TV_rank_score.setText(rank.substring(5));
                        //      TV_rank_rate.setText(rate);
                        TextView TV_rank_msg = findViewById(R.id.TV_rankdetail_msg);
                        TV_rank_msg.setText(msg);
                        if(image.exists()) {
                            Bitmap myBitmap = BitmapFactory.decodeFile(image.getAbsolutePath());
                            IV_head.setImageBitmap(myBitmap);
                        }
                        // 設置Dialog的寬度為使用者螢幕寬度的80%
                        WindowManager.LayoutParams params = getWindow().getAttributes();
                        DisplayMetrics metrics = getResources().getDisplayMetrics();
                        int screenWidth = metrics.widthPixels;
                        params.width = (int) (screenWidth * 0.8);
                        getWindow().setAttributes(params);
                    }
                };
                myBuilder.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                myBuilder.show();

            }

        });
        gettop10();
    }

    public void reloaddata(String[] input){
        items.clear();
        int count=0;
        for(String uid:input){
            int finalCount = count;
            ref.child(uid).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    int score = snapshot.child("score").getValue(Integer.class);
                    String name = snapshot.child("name").getValue(String.class);
                    String message = snapshot.child("message").getValue(String.class);
                    Map<String, Object> item = new HashMap<>();
                    item.put("score", score);
                    item.put("name",name);
                    item.put("message",message);
                    items.add(item);
                    String rank = "第"+(finalCount +1)+"名 - "+score+"分";
                    items.get(finalCount).put("rank",rank);
                    StorageReference imageRef = storage.child(uid).child("image.png");
                    try {
                        File localFile = File.createTempFile("image", "png");
                        imageRef.getFile(localFile).addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                                // 下載成功，將圖片存在items中
                                items.get(finalCount).put("image",localFile);

                                SimpleAdapter simpleadapte = new SimpleAdapter(RankActivity.this
                                        , items
                                        , R.layout.item_rank_layout
                                        , dataname
                                        , view_address);
                                listview.setAdapter(simpleadapte);
                                simpleadapte.notifyDataSetChanged();
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception exception) {
                                // 下載失敗，輸出錯誤訊息
                                Log.e("TAG", "下載失敗：" + exception.getMessage());
                                storage.child("userdefault.jpg").getFile(localFile).addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
                                    @Override
                                    public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                                        // 下載成功，將圖片顯示在ImageView中
                                        Log.d("TAG","success");
                                        items.get(finalCount).put("image",localFile);

                                        SimpleAdapter simpleadapte = new SimpleAdapter(RankActivity.this
                                                , items
                                                , R.layout.item_rank_layout
                                                , dataname
                                                , view_address);
                                        listview.setAdapter(simpleadapte);
                                        simpleadapte.notifyDataSetChanged();
                                    }
                                }).addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception exception) {
                                        // 下載失敗，輸出錯誤訊息
                                        Log.e("TAG","fail No"+finalCount);
                                    }
                                });
                            }
                        });
                    } catch (IOException e) {
                        // 輸出錯誤訊息
                        e.printStackTrace();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
            count++;
        }
//        ref.addListenerForSingleValueEvent(new ValueEventListener() {
//            @Override
//            public void onDataChange(DataSnapshot dataSnapshot) {
//                // 处理数据
//                items.clear();
//                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
//                    String uid = snapshot.getKey();
//                    int score = snapshot.child("score").getValue(Integer.class);
//                    String name = snapshot.child("name").getValue(String.class);
//                    String message = snapshot.child("message").getValue(String.class);
//                    Map<String, Object> item = new HashMap<>();
//                    item.put("uid", uid);
//                    item.put("score", score);
//                    item.put("name",name);
//                    item.put("message",message);
//                    items.add(item);
//                }
//                Log.d("before", items.toString());
//                // 按值排序
//                Collections.sort(items, new Comparator<Map<String, Object>>() {
//                    public int compare(Map<String, Object> o1, Map<String, Object> o2) {
//                        int score1 = (int) o1.get("score");
//                        int score2 = (int) o2.get("score");
//                        return Integer.compare(score2, score1);
//                    }
//                });
//                // 将排序后的 List 转换为 ArrayList
//                Log.d("after", items.toString());
//                輸出到畫面上
//                for (int i = 0; i < input.length; i++) {
//                    String rank = "第"+(i+1)+"名 -"+items.get(i).get("score").toString()+"分";
//                    items.get(i).put("rank",rank);
//                    StorageReference imageRef = storage.child(uid).child("image.png");
//                    try {
//                        File localFile = File.createTempFile("image", "png");
//                        int finalI = i;
//                        imageRef.getFile(localFile).addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
//                            @Override
//                            public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
//                                // 下載成功，將圖片存在items中
//                                items.get(finalI).put("image",localFile);
//
//                                SimpleAdapter simpleadapte = new SimpleAdapter(RankActivity.this
//                                        , items
//                                        , R.layout.item_rank_layout
//                                        , dataname
//                                        , view_address);
//                                listview.setAdapter(simpleadapte);
//                                simpleadapte.notifyDataSetChanged();
//                            }
//                        }).addOnFailureListener(new OnFailureListener() {
//                            @Override
//                            public void onFailure(@NonNull Exception exception) {
//                                // 下載失敗，輸出錯誤訊息
//                                Log.e("TAG", "下載失敗：" + exception.getMessage());
//                                storage.child("userdefault.jpg").getFile(localFile).addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
//                                    @Override
//                                    public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
//                                        // 下載成功，將圖片顯示在ImageView中
//                                        Log.d("TAG","success");
//                                        items.get(finalI).put("image",localFile);
//
//                                        SimpleAdapter simpleadapte = new SimpleAdapter(RankActivity.this
//                                                , items
//                                                , R.layout.item_rank_layout
//                                                , dataname
//                                                , view_address);
//                                        listview.setAdapter(simpleadapte);
//                                        simpleadapte.notifyDataSetChanged();
//                                    }
//                                }).addOnFailureListener(new OnFailureListener() {
//                                    @Override
//                                    public void onFailure(@NonNull Exception exception) {
//                                        // 下載失敗，輸出錯誤訊息
//                                        Log.e("TAG","fail No"+finalI);
//                                    }
//                                });
//                            }
//                        });
//                    } catch (IOException e) {
//                        // 輸出錯誤訊息
//                        e.printStackTrace();
//                    }
//
//                }
//                SimpleAdapter simpleadapte = new SimpleAdapter(RankActivity.this
//                        , items
//                        , R.layout.item_rank_layout
//                        , dataname
//                        , view_address);
//                listview.setAdapter(simpleadapte);
//                simpleadapte.notifyDataSetChanged();
//            }
//
//            @Override
//            public void onCancelled(DatabaseError databaseError) {
//                // 处理取消操作
//                Log.e("DataSnapshot", databaseError.toString());
//            }
//        });
    }

    private String geturl(String action, String[] input){
        String outurl = ogurl + "?action=" + action;
        for ( int i = 0; i < input.length ; i+=2 ){
            outurl = outurl + "&" + input[i] + "=" + input[i+1];
        }

        return outurl;
    }
    public void gettop10(){
//        Dialog loading = new Dialog(RankActivity.this);
//        loading.setContentView(R.layout.dialog_loading);
//        Window window = loading.getWindow();
//        if (window != null) {
//            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
//        }
//        ProgressBar progressBar = loading.findViewById(R.id.progressBar);
//        loading.show();
        loading loading = new loading(RankActivity.this);
        String url = geturl("gettop10rank", new String[]{});
        System.out.println(url);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                String[] parts = response.split("&");
                reloaddata(parts);
//                loading.dismiss();
                loading.finish();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                System.out.println("========排行出問題=========");
            }

        });

        RequestQueue queue = Volley.newRequestQueue(RankActivity.this);
        queue.add(stringRequest);
    }
}