package com.example.ex_4;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

import java.io.File;

import de.hdodenhof.circleimageview.CircleImageView;

public class homepage extends AppCompatActivity {
    private String uid,name;
    private int point,BET;
    private CircleImageView my_image;
    private ImageView imageViewBeginer,btn_quickstart;
    private ImageView btn_rank;
    private LinearLayout layout_detail;
    private ImageView btn_shop;
    private TextView TV_HP_shop,TV_HP_playername,TV_HP_point,TV_HP_UID;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);

        sharedPreferences = getSharedPreferences("my_prefs", Context.MODE_PRIVATE);

        uid = sharedPreferences.getString("uid","");
        point = sharedPreferences.getInt("point",0);
        name = sharedPreferences.getString("name","");
        BET= sharedPreferences.getInt("BET",50);

        my_image = findViewById(R.id.my_image);
        show_photo();
        imageViewBeginer =(ImageView) findViewById(R.id.btn_gmaestart);
        imageViewBeginer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                Intent ab = new Intent(homepage.this, choose_chips.class);
                startActivity(ab);
            }
        });

        btn_rank = (ImageView) findViewById(R.id.imageView_rank);
        btn_rank.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(homepage.this,RankActivity.class);
                startActivity(it);
            }
        });
        TV_HP_shop = (TextView)findViewById(R.id.TV_HP_shop);
        TV_HP_shop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(homepage.this,MainActivityshop.class);
                startActivity(it);
            }
        });
        btn_shop = (ImageView) findViewById(R.id.imageView_shop);
        btn_shop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(homepage.this,MainActivityshop.class);
                startActivity(it);
            }
        });


        layout_detail = (LinearLayout) findViewById(R.id.linearLayout_HP_status);
        layout_detail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(homepage.this,MainActivityedit.class);
                startActivity(it);
            }
        });
        TV_HP_playername = findViewById(R.id.TV_HP_playername);
        TV_HP_point = findViewById(R.id.TV_HP_point);
        TV_HP_playername.setText(name);
        TV_HP_point.setText("Point:"+point);

        btn_quickstart = findViewById(R.id.button_quickstart);
        btn_quickstart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(homepage.this,MainActivitycardgame.class);
                startActivity(it);
            }
        });
        change_QuickSrtart();
    }
    public void show_photo(){
        String fileName = "image.png";
        File file = new File(getFilesDir(), fileName);
        if (file.exists()) {
            Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
            my_image.setImageBitmap(bitmap);
        }else{
            Log.d("image", "file no exists");
        }
    }
    public void change_QuickSrtart(){
        switch (BET){
            case 50:
                btn_quickstart.setImageResource(R.drawable.beginer_blue);
                break;
            case 100:
                btn_quickstart.setImageResource(R.drawable.exp_purple);
                break;
            case 500:
                btn_quickstart.setImageResource(R.drawable.issue_purple);
                break;
            case 2000:
                btn_quickstart.setImageResource(R.drawable.mad_pink);
                break;
            case 10000:
                btn_quickstart.setImageResource(R.drawable.danger_red);
                break;
        }
    }

    @Override
    public void onBackPressed() {
        // 在这里添加你的逻辑代码
        // 这个 Activity 将不会响应返回键
        return;
    }

    @Override
    protected void onResume() {
        super.onResume();
        show_photo();
        name = sharedPreferences.getString("name","");
        point = sharedPreferences.getInt("point",0);
        BET= sharedPreferences.getInt("BET",50);
        TV_HP_point.setText("point:"+point);
        TV_HP_playername.setText(name);
        change_QuickSrtart();
    }

}