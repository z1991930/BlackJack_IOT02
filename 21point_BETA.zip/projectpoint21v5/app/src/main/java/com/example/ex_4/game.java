package com.example.ex_4;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class game {
    public List<Card> deck;
    public List<Card> playerCards;
    public List<Card> dealerCards;
//    public HashMap<Card,Integer> IV_card;
    private int[][] card_drawble={
            {R.drawable.clubs_1,R.drawable.clubs_2,R.drawable.clubs_3,R.drawable.clubs_4,R.drawable.clubs_5,R.drawable.clubs_6,R.drawable.clubs_7,R.drawable.clubs_8,R.drawable.clubs_9,R.drawable.clubs_10,R.drawable.clubs_11,R.drawable.clubs_12,R.drawable.clubs_13},
            {R.drawable.diamonds_1,R.drawable.diamonds_2,R.drawable.diamonds_3,R.drawable.diamonds_4,R.drawable.diamonds_5,R.drawable.diamonds_6,R.drawable.diamonds_7,R.drawable.diamonds_8,R.drawable.diamonds_9,R.drawable.diamonds_10,R.drawable.diamonds_11,R.drawable.diamonds_12,R.drawable.diamonds_13},
            {R.drawable.hearts_1,R.drawable.hearts_2,R.drawable.hearts_3,R.drawable.hearts_4,R.drawable.hearts_5,R.drawable.hearts_6,R.drawable.hearts_7,R.drawable.hearts_8,R.drawable.hearts_9,R.drawable.hearts_10,R.drawable.hearts_11,R.drawable.hearts_12,R.drawable.hearts_13},
            {R.drawable.spades_1,R.drawable.spades_2,R.drawable.spades_3,R.drawable.spades_4,R.drawable.spades_5,R.drawable.spades_6,R.drawable.spades_7,R.drawable.spades_8,R.drawable.spades_9,R.drawable.spades_10,R.drawable.spades_11,R.drawable.spades_12,R.drawable.spades_13}};

    public game() {
        deck = new ArrayList<>();
        playerCards = new ArrayList<>();
        dealerCards = new ArrayList<>();

        // 创建一副牌
        for (Card.Suit suit : Card.Suit.values()) {
            for (Card.Rank rank : Card.Rank.values()) {
                deck.add(new Card(rank, suit));
            }
        }
//        int deck_i = 0;
//        IV_card = new HashMap<>();
//        for (int i=0;i<4;i++){
//            for (int j=0;j<13;j++){
//                IV_card.put(deck.get(deck_i),card_drawble[i][j]);
//                deck_i++;
//            }
//        }
        // 洗牌
        Collections.shuffle(deck);
    }

    public int getPlayerScore() {
        return getScore(playerCards);
    }

    public int getDealerScore() {
        return getScore(dealerCards);
    }

    public void dealInitialCards() {
        playerCards.add(deck.remove(0));
        dealerCards.add(deck.remove(0));
        playerCards.add(deck.remove(0));
        dealerCards.add(deck.remove(0));
    }

    public void playerHit() {
        playerCards.add(deck.remove(0));
    }

    public void dealerHit() {
        dealerCards.add(deck.remove(0));
    }

    public boolean isPlayerBust() {
        return getPlayerScore() > 21;
    }

    public boolean isDealerBust() {
        return getDealerScore() > 21;
    }

    public boolean isPlayerWin() {
        return getPlayerScore() > getDealerScore() || isDealerBust();
    }

    public boolean isDealerWin() {
        return getDealerScore() > getPlayerScore() || isPlayerBust();
    }

    public boolean isGameEnd() {
        return isPlayerBust() || isDealerBust() || playerCards.size() == 5 || dealerCards.size() == 5;
    }

    public int getScore(List<Card> cards) {
        int score = 0;
        int numOfAces = 0;

        for (Card card : cards) {
            if (card.getRank() == Card.Rank.ACE) {
                numOfAces++;
            }
            score += card.getValue();
        }

        while (score > 21 && numOfAces > 0) {
            score -= 10;
            numOfAces--;
        }

        return score;
    }

    public static class Card {
        enum Suit {
            CLUBS,
            DIAMONDS,
            HEARTS,
            SPADES
        }

        enum Rank {
            ACE(11),
            TWO(2),
            THREE(3),
            FOUR(4),
            FIVE(5),
            SIX(6),
            SEVEN(7),
            EIGHT(8),
            NINE(9),
            TEN(10),
            JACK(10),
            QUEEN(10),
            KING(10);

            private final int value;

            Rank(int value) {
                this.value = value;
            }

            public int getValue() {
                return value;
            }
        }

        private final Rank rank;
        private final Suit suit;

        public Card(Rank rank, Suit suit) {
            this.rank = rank;
            this.suit = suit;
        }

        public int getValue() {
            return rank.getValue();
        }

        public Rank getRank() {
            return rank;
        }

        public Suit getSuit() {
            return suit;
        }
    }

    public int get_card_image(Card card){
        int i,j;
        i=j=0;
        if(card.getSuit().equals(Card.Suit.CLUBS)){
            i=0;
        }else if (card.getSuit().equals(Card.Suit.DIAMONDS)){
            i=1;
        }else if (card.getSuit().equals(Card.Suit.HEARTS)){
            i=2;
        }else if (card.getSuit().equals(Card.Suit.SPADES)){
            i=3;
        }
        j=card.getValue()-1;
        if(j>=9){
            if(card.getRank().equals(Card.Rank.TEN)){
                j=9;
            }else if(card.getRank().equals(Card.Rank.JACK)){
                j=10;
            }else if(card.getRank().equals(Card.Rank.QUEEN)){
                j=11;
            }else if(card.getRank().equals(Card.Rank.KING)){
                j=12;
            }else if(card.getRank().equals(Card.Rank.ACE)){
                j=0;
            }
        }

        return card_drawble[i][j];
    }
}
