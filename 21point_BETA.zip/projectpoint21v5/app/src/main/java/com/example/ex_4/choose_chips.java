package com.example.ex_4;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Image;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;

import de.hdodenhof.circleimageview.CircleImageView;


public class choose_chips extends AppCompatActivity {

    private ImageView imageViewRulerIntent,IV_beginer,IV_exp,IV_risk,IV_mad,IV_nolife;

    private String uid,name;
    private int point,BET;
    private CircleImageView my_image;
    private LinearLayout layout_detail;
    private TextView TV_HP_shop,TV_HP_playername,TV_HP_point,TV_HP_UID;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_chips);

        sharedPreferences = getSharedPreferences("my_prefs", Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
        uid = sharedPreferences.getString("uid","");
        point = sharedPreferences.getInt("point",0);
        name = sharedPreferences.getString("name","");

        my_image = findViewById(R.id.my_image);
        imageViewRulerIntent =(ImageView) findViewById(R.id.imageView_rule_intent);
        imageViewRulerIntent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ab = new Intent(choose_chips.this, rule.class);
                startActivity(ab);
            }
        });
        ImageButton back = (ImageButton) findViewById(R.id.backtohome);

        IV_beginer = findViewById(R.id.imageView_begin);
        IV_exp = findViewById(R.id.imageView_danger);
        IV_risk = findViewById(R.id.imageView8_rich);
        IV_mad = findViewById(R.id.imageView_dream);
        IV_nolife = findViewById(R.id.imageView_soul);
        IV_beginer.setOnClickListener(new BET_chioce());
        IV_exp.setOnClickListener(new BET_chioce());
        IV_risk.setOnClickListener(new BET_chioce());
        IV_mad.setOnClickListener(new BET_chioce());
        IV_nolife.setOnClickListener(new BET_chioce());

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        layout_detail = (LinearLayout) findViewById(R.id.linearLayout_HP_status);
        layout_detail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(choose_chips.this,MainActivityedit.class);
                startActivity(it);
            }
        });
        TV_HP_playername = findViewById(R.id.TV_HP_playername);
        TV_HP_point = findViewById(R.id.TV_HP_point);
        TV_HP_playername.setText(name);
        TV_HP_point.setText("Point:"+point);
        show_image();
        TV_HP_shop = (TextView)findViewById(R.id.TV_HP_shop);
        TV_HP_shop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(choose_chips.this,MainActivityshop.class);
                startActivity(it);
            }
        });

    }


    private class BET_chioce implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.imageView_begin:
                    BET = 50;
                    break;
                case R.id.imageView_danger:
                    BET = 100;
                    break;
                case R.id.imageView8_rich:
                    BET = 500;
                    break;
                case R.id.imageView_dream:
                    BET = 2000;
                    break;
                case R.id.imageView_soul:
                    BET = 10000;
                    break;
            }
            editor.putInt("BET",BET);
            editor.apply();
            Intent it = new Intent(choose_chips.this,MainActivitycardgame.class);
            startActivity(it);
        }
    }
    @Override
    protected void onResume() {
        super.onResume();
        name = sharedPreferences.getString("name","");
        point = sharedPreferences.getInt("point",0);
        BET= sharedPreferences.getInt("BET",50);
        TV_HP_point.setText("point:"+point);
        TV_HP_playername.setText(name);
        show_image();
    }
    protected void show_image(){
        String fileName = "image.png";
        File file = new File(getFilesDir(), fileName);
        if (file.exists()) {
            Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
            my_image.setImageBitmap(bitmap);
        }else{
            Log.d("image", "file no exists");
        }
    }
}