package com.example.ex_4;

import android.graphics.Bitmap;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class MyShareViewModel extends ViewModel {
    private MutableLiveData<Bitmap> bitmapLiveData = new MutableLiveData<>();

    public void setBitmap(Bitmap bitmap) {
        bitmapLiveData.setValue(bitmap);
    }

    public LiveData<Bitmap> getBitmap() {
        return bitmapLiveData;
    }
}

