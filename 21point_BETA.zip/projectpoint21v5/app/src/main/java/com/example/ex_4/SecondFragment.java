package com.example.ex_4;


import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import java.util.ArrayList;




/**
 * A simple {@link Fragment} subclass.
 */
class itemp {

    public char index;

    public String cardname;

    public String carddetail;
    public int picture;
    public char curstr;
    public boolean isbuy;

    public int cost;
    public LinearLayout itemlinearLayout;
    public TextView itemtextView;

    public itemp(){

    }

}
public class SecondFragment extends Fragment {

    private TextView itemText;

    private ArrayList<itemp> itempList = new ArrayList<>();

    private Dialog dialog;

    private Toast toast;

    private MySharedViewModel sharedViewModel;

    public void setSharedViewModel(MySharedViewModel viewModel) {
        sharedViewModel = viewModel;
    }

    public SecondFragment() {
        // Required empty public constructor
    }


    @SuppressLint({"MissingInflatedId", "SetTextI18n"})
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        sharedViewModel = new ViewModelProvider(requireActivity()).get(MySharedViewModel.class);

        usermoney = sharedViewModel.getUserMoney().getValue();

        // 獲取usermoney參數的值
        sharedViewModel.getUserMoney().observe(getViewLifecycleOwner(), money -> {
            // 更新UI
            usermoney = money;
        });

        usingstring = sharedViewModel.getuseracardback().getValue();
        buystring = sharedViewModel.getuserhcardback().getValue();





//==============================================================================================================
        View view = inflater.inflate(R.layout.fragment_second, container, false);
        TextView[] copytext = {view.findViewById(R.id.item_text1),view.findViewById(R.id.item_text2)
                ,view.findViewById(R.id.item_text3),view.findViewById(R.id.item_text4)
                ,view.findViewById(R.id.item_text5),view.findViewById(R.id.item_text6)};
        LinearLayout[] copylinearLayout = {view.findViewById(R.id.layoutp1),view.findViewById(R.id.layoutp2)
                ,view.findViewById(R.id.layoutp3),view.findViewById(R.id.layoutp4)
                ,view.findViewById(R.id.layoutp5),view.findViewById(R.id.layoutp6)};

        ImageView[] item_image = {  view.findViewById(R.id.item_image),view.findViewById(R.id.item_image2),
                view.findViewById(R.id.item_image3),view.findViewById(R.id.item_image4),
                view.findViewById(R.id.item_image5),view.findViewById(R.id.item_image6)};

        int[] copydrawable = {R.drawable.card1,R.drawable.card2,R.drawable.card3,R.drawable.card4,R.drawable.card5,R.drawable.card6};
        int[] cardcost = {0,500,2000,2000,5000,20000};
        String[] copyCardName = {"基本","Bicycle Red","神燈精靈","黃金星光","滿月的夜空","星光蔽月"};
        String[] copyCarddetail = { "你當前已經使用這張卡背",
                                    "你知道製作這張牌的公司在1885年就已經成立了嗎?",
                                    "很明顯用紅色卡背抽到的數字會比較大",
                                    "你只要有21點就不可能輸了",
                                    "你是不是很好奇這裡會有甚麼描述?",
                                    "簡約一些更好看"};
//==============================================================================================================

        for(int i = 0 ; i < 6 ; i++ ){
            Drawable green = ContextCompat.getDrawable(requireContext(), R.drawable.greenborder);
            Drawable white = ContextCompat.getDrawable(requireContext(), R.drawable.whiteborder);
            itemp item = new itemp();
            item.itemtextView = copytext[i];
            item.itemlinearLayout = copylinearLayout[i];
            item.picture = copydrawable[i];
            item.cardname = copyCardName[i];
            item.carddetail = copyCarddetail[i];
            item_image[i].setImageResource(copydrawable[i]);

            item.cost = cardcost[i]  ;
            String c = charonetoA(i)+"";

            if(buystring.contains(c)){
                item.isbuy = true;
                item.itemtextView.setText("已擁有");
                item.itemtextView.setTextColor(0xFFEC5B5B);
            }
            else {
                item.isbuy = false;
                item.itemtextView.setTextColor(0xFFFFFFFF);
                item.itemtextView.setText(item.cost+"p");
            }


            if(charAtoone(usingstring)==i ) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                    item.itemlinearLayout.setBackground(green);
                    item.itemtextView.setTextColor(0xFF409300);
                    item.itemtextView.setText("使用中");
                }
            }
            else{
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                    item.itemlinearLayout.setBackground(white);
                }
            }


            item.index = charonetoA(i);
            item.curstr = charonetoA(i);
            itempList.add(item);
        }


        dialog = new Dialog(this.getActivity());

        for(int i = 0 ; i < 6 ; i++ ){
            final int finalI = i;
            itempList.get(i).itemlinearLayout.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    if(itempList.get(finalI).isbuy==true){
                        if( itempList.get(finalI).index == usingstring){ // 點擊已使用卡背


                            dialog.setContentView(R.layout.custom_dialog);
                            final TextView message = dialog.findViewById(R.id.dialog_message);
                            final TextView title = dialog.findViewById(R.id.dialog_title);
                            final TextView cost = dialog.findViewById(R.id.item_cost);
                            final ImageView icardimage =  dialog.findViewById(R.id.item_image);

                            icardimage.setImageResource(itempList.get(finalI).picture);

                            Context context = getContext();
                            DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
                            float dpWidth = displayMetrics.widthPixels;
                            float dpHeight = displayMetrics.heightPixels;

                            ConstraintLayout dialogLayout = dialog.findViewById(R.id.diglog);
                            ViewGroup.LayoutParams params = dialogLayout.getLayoutParams();
                            params.width = (int) (dpWidth * 0.8);
                            params.height = (int) (dpHeight * 0.5);
                            dialogLayout.setLayoutParams(params);


                            title.setText(itempList.get(finalI).cardname);
                            message.setText(itempList.get(finalI).carddetail);
                            message.setTextColor(0xFF409300);
                            cost.setText(itempList.get(finalI).cost+"p");

                            Button okButton = dialog.findViewById(R.id.dialog_ok_button);
                            okButton.setEnabled(false);
                            okButton.setVisibility(View.INVISIBLE);

                            Button calcelButton = dialog.findViewById(R.id.dialog_calcelbutton);
                            calcelButton.setEnabled(false);
                            calcelButton.setVisibility(View.INVISIBLE);

                            Button centerButton = dialog.findViewById(R.id.dialog_centerbutton);
                            centerButton.setEnabled(true);
                            centerButton.setVisibility(View.VISIBLE);

                            centerButton.setText("返回");

                            centerButton.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {


                                    if (toast != null) {
                                        toast.cancel();
                                    }

                                    // 顯示新的 Toast
                                    dialog.dismiss();
                                }
                            });


                            dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
                                @Override
                                public void onCancel(DialogInterface dialog) {
                                    if (toast != null) {
                                        toast.cancel();
                                    }

                                    // 顯示新的 Toast
                                    toast = Toast.makeText(context, "失敗!", Toast.LENGTH_SHORT);
                                    //toast.show();
                                }
                            });

                            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                            dialog.getWindow().setDimAmount(0.0f);
                            dialog.show();

                            if (toast != null) {
                                toast.cancel();
                            }

                            // 顯示新的 Toast
                            toast = Toast.makeText(getActivity(), "你已經在使用這個卡背", Toast.LENGTH_SHORT);
                            //toast.show();

                        }
                        else{ // 點擊新卡背
                            Drawable green = ContextCompat.getDrawable(requireContext(), R.drawable.greenborder);
                            Drawable white = ContextCompat.getDrawable(requireContext(), R.drawable.whiteborder);
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                                itempList.get(charAtoone(usingstring)).itemlinearLayout.setBackground(white);
                                itempList.get(charAtoone(usingstring)).itemtextView.setText("已擁有");
                                itempList.get(charAtoone(usingstring)).itemtextView.setTextColor(0xFFEC5B5B);
                                usingstring = charonetoA(finalI);
                                sharedViewModel.setUseruseracardback(usingstring);
                                itempList.get(charAtoone(usingstring)).itemlinearLayout.setBackground(green);
                                itempList.get(charAtoone(usingstring)).itemtextView.setText("使用中");
                                itempList.get(charAtoone(usingstring)).itemtextView.setTextColor(0xFF409300);
                            }}


                    }
                    else{
                        if(itempList.get(finalI).cost>usermoney){

                            dialog.setContentView(R.layout.custom_dialog);
                            final TextView message = dialog.findViewById(R.id.dialog_message);
                            final TextView title = dialog.findViewById(R.id.dialog_title);
                            final TextView cost = dialog.findViewById(R.id.item_cost);
                            final ImageView icardimage =  dialog.findViewById(R.id.item_image);

                            icardimage.setImageResource(itempList.get(finalI).picture);

                            Context context = getContext();
                            DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
                            float dpWidth = displayMetrics.widthPixels;
                            float dpHeight = displayMetrics.heightPixels;

                            ConstraintLayout dialogLayout = dialog.findViewById(R.id.diglog);
                            ViewGroup.LayoutParams params = dialogLayout.getLayoutParams();
                            params.width = (int) (dpWidth * 0.8);
                            params.height = (int) (dpHeight * 0.5);
                            dialogLayout.setLayoutParams(params);


                            title.setText(itempList.get(finalI).cardname);
                            message.setText("你的點數不夠");
                            message.setTextColor(0xFFEC5B5B);
                            cost.setText(itempList.get(finalI).cost+"p");

                            Button okButton = dialog.findViewById(R.id.dialog_ok_button);
                            okButton.setEnabled(false);
                            okButton.setVisibility(View.INVISIBLE);

                            Button calcelButton = dialog.findViewById(R.id.dialog_calcelbutton);
                            calcelButton.setEnabled(false);
                            calcelButton.setVisibility(View.INVISIBLE);

                            Button centerButton = dialog.findViewById(R.id.dialog_centerbutton);
                            centerButton.setEnabled(true);
                            centerButton.setVisibility(View.VISIBLE);

                            centerButton.setText("返回");

                            centerButton.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {


                                    if (toast != null) {
                                        toast.cancel();
                                    }

                                    // 顯示新的 Toast
                                    dialog.dismiss();
                                }
                            });


                            dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
                                @Override
                                public void onCancel(DialogInterface dialog) {
                                    if (toast != null) {
                                        toast.cancel();
                                    }

                                    // 顯示新的 Toast
                                    toast = Toast.makeText(context, "失敗!", Toast.LENGTH_SHORT);
                                    //toast.show();
                                }
                            });

                            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                            dialog.getWindow().setDimAmount(0.0f);
                            dialog.show();

                            if (toast != null) {
                                toast.cancel();
                            }

                            // 顯示新的 Toast
                            toast = Toast.makeText(getActivity(), "你的點數不夠", Toast.LENGTH_SHORT);
                            //toast.show();

                        }
                        else{
                            dialog.setContentView(R.layout.custom_dialog);
                            final TextView message = dialog.findViewById(R.id.dialog_message);
                            final TextView title = dialog.findViewById(R.id.dialog_title);
                            final TextView cost = dialog.findViewById(R.id.item_cost);
                            final ImageView icardimage =  dialog.findViewById(R.id.item_image);

                            icardimage.setImageResource(itempList.get(finalI).picture);

                            Context context = getContext();
                            DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
                            float dpWidth = displayMetrics.widthPixels;
                            float dpHeight = displayMetrics.heightPixels;

                            ConstraintLayout dialogLayout = dialog.findViewById(R.id.diglog);
                            ViewGroup.LayoutParams params = dialogLayout.getLayoutParams();
                            params.width = (int) (dpWidth * 0.8);
                            params.height = (int) (dpHeight * 0.5);
                            dialogLayout.setLayoutParams(params);


                            title.setText(itempList.get(finalI).cardname);
                            message.setText("現有  "+usermoney + " → 購買後 "+(usermoney- itempList.get(finalI).cost));
                            message.setTextColor(0xFF000000);
                            cost.setText(itempList.get(finalI).cost+"p");

                            Button okButton = dialog.findViewById(R.id.dialog_ok_button);
                            okButton.setEnabled(true);
                            okButton.setVisibility(View.VISIBLE);

                            Button calcelButton = dialog.findViewById(R.id.dialog_calcelbutton);
                            calcelButton.setEnabled(true);
                            calcelButton.setVisibility(View.VISIBLE);

                            Button centerButton = dialog.findViewById(R.id.dialog_centerbutton);
                            centerButton.setEnabled(false);
                            centerButton.setVisibility(View.INVISIBLE);

                            okButton.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {


                                    if (toast != null) {
                                        toast.cancel();
                                    }

                                    // 顯示新的 Toast
                                    toast = Toast.makeText(context, "購買成功!", Toast.LENGTH_SHORT);
                                    toast.show();

                                    itempList.get(finalI).isbuy = true;
                                    itempList.get(finalI).itemtextView.setText("已購買!");
                                    buystring = buystring + charonetoA(finalI);

                                    sharedViewModel.setUseruserhcardback(buystring);

                                    //System.out.println("char new = "+ charonetoA(finalI));
                                    itempList.get(finalI).itemtextView.setTextColor(0xFFEC5B5B);
                                    usermoney = usermoney - itempList.get(finalI).cost;
                                    sharedViewModel.setUserMoney(usermoney);
                                    dialog.dismiss();
                                }
                            });


                            calcelButton.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {

                                    if (toast != null) {
                                        toast.cancel();
                                    }

                                    // 顯示新的 Toast
                                    toast = Toast.makeText(context, "取消!", Toast.LENGTH_SHORT);
                                    //toast.show();

                                    dialog.dismiss();
                                }
                            });

                            dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
                                @Override
                                public void onCancel(DialogInterface dialog) {
                                    if (toast != null) {
                                        toast.cancel();
                                    }

                                    // 顯示新的 Toast
                                    toast = Toast.makeText(context, "失敗!", Toast.LENGTH_SHORT);
                                    //toast.show();
                                }
                            });

                            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                            dialog.getWindow().setDimAmount(0.0f);
                            dialog.show();

                        }

                    }

//                    Drawable drawable = ContextCompat.getDrawable(requireContext(), R.drawable.whiteborder);
//                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
//                        itempList.get(finalI).itemlinearLayout.setBackground(drawable);
//                    }
                }
            });
        }

        return view;
    }

    public void setItemText(String text) {
        itemText.setText(text);
    }

    public char charonetoA(int input ) { return (char)(input  + 65); }

    public int charAtoone(char input ) { return ((int)(input) - 65); };

    private String buystring = "ADF";
    private char usingstring = 'D';

    private int usermoney = 0;
}