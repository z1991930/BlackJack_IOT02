package com.example.ex_4;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.core.view.GestureDetectorCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class MainActivitycardgame extends AppCompatActivity {

    private Button btn_hit, btn_deal, btn_stand, btn_bet;
    private ImageView IV_player1, IV_player2, IV_player3, IV_player4, IV_player5, IV_dealer1, IV_dealer2, IV_dealer3, IV_dealer4, IV_dealer5;
    private TextView tv_dealer_score, tv_player_score, tv_point, tv_bet;
    private game nw_game = new game();
    private boolean game_is_start = false, btn_betFlag = true,game_is_set=false;
    private ConstraintLayout layout_game;
    protected int lpoint, score;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    private int BET;
    private String uid, ogurl, id;
    protected DatabaseReference uref = FirebaseDatabase.getInstance().getReference().child("userinfo");

    int card_used;
    int table_used;
    char[] list = {'A', 'B', 'C', 'D', 'E', 'F'};
    int[] tableimage_list = {R.drawable.table1, R.drawable.table2, R.drawable.table3, R.drawable.table4, R.drawable.table5, R.drawable.table6};
    int[] cardimage_list = {R.drawable.card1, R.drawable.card2, R.drawable.card3, R.drawable.card4, R.drawable.card5, R.drawable.card6};
    Map<Character, Integer> card_list = new HashMap<Character, Integer>();
    Map<Character, Integer> table_list = new HashMap<Character, Integer>();
    private ImageButton Ibtn_game_rule;
    private GestureDetectorCompat gestureDetector;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maingame);

        for (int i = 0; i < list.length; i++) {
            card_list.put(list[i], cardimage_list[i]);
            table_list.put(list[i], tableimage_list[i]);
        }

        sharedPreferences = getSharedPreferences("my_prefs", Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
        BET = sharedPreferences.getInt("BET", 50);
        uid = sharedPreferences.getString("uid", "");
        card_used = sharedPreferences.getInt("card_used", 'A');
        table_used = sharedPreferences.getInt("table_used", 'A');
        ogurl = sharedPreferences.getString("url", "");
        id = sharedPreferences.getString("ID", "");
        gestureDetector = new GestureDetectorCompat(this, new MyGestureListener());

        ImageButton back = findViewById(R.id.backtochip);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        //按鍵
        btn_hit = (Button) findViewById(R.id.btn_hit);
        btn_stand = findViewById(R.id.btn_stand);
        btn_deal = findViewById(R.id.btn_deal);
        btn_bet = findViewById(R.id.btn_bet);

        IV_player1 = (ImageView) findViewById(R.id.IV_player1);
        IV_player2 = (ImageView) findViewById(R.id.IV_player2);
        IV_player3 = (ImageView) findViewById(R.id.IV_player3);
        IV_player4 = (ImageView) findViewById(R.id.IV_player4);
        IV_player5 = (ImageView) findViewById(R.id.IV_player5);
        IV_dealer1 = (ImageView) findViewById(R.id.IV_dealer1);
        IV_dealer2 = (ImageView) findViewById(R.id.IV_dealer2);
        IV_dealer3 = (ImageView) findViewById(R.id.IV_dealer3);
        IV_dealer4 = (ImageView) findViewById(R.id.IV_dealer4);
        IV_dealer5 = (ImageView) findViewById(R.id.IV_dealer5);

        tv_player_score = (TextView) findViewById(R.id.tv_player_score);
        tv_dealer_score = (TextView) findViewById(R.id.tv_dealer_score);
        tv_point = (TextView) findViewById(R.id.tv_point);
        tv_bet = findViewById(R.id.tv_bet);
        layout_game = (ConstraintLayout) findViewById(R.id.layout_game);
        Ibtn_game_rule = (ImageButton)findViewById(R.id.Ibtn_game_rule);
        Ibtn_game_rule.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ab = new Intent(MainActivitycardgame.this, rule.class);
                startActivity(ab);
            }
        });

        layout_game.setBackgroundResource(table_list.get((char) table_used));

        //Double Tap
        layout_game.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
//                Log.d(">>>", "onTouch");
//                return true;

                //使用手勢
                return gestureDetector.onTouchEvent(event);
            }
        });



        btn_deal.setText(BET + " point");


//        uid = "5MQaBGHHCoMVxQ6q8uJv8y1QSlP2";

        getUserpoint(uid, new OnUserpointCallback() {
            @Override
            public void onUserpoint(int point) {
                lpoint = point;
                tv_point.setText("POINT : " + lpoint + "");
            }
        });
        uref.child(uid).child("score").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                score = snapshot.getValue(Integer.class);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        tv_point.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                charge();
            }
        });
        tv_bet.setText("BET : " + BET + "");

        game_set();
        game_restart();

        btn_bet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!game_is_start) {
                    if (btn_betFlag) {
                        if (lpoint >= BET * 2) {
                            BET *= 2;
                            btn_deal.setText(BET + " point");
                            tv_bet.setText("BET : " + BET + "");
                            btn_bet.setText("取消加注");
                            btn_betFlag = false;
                        } else {
                            charge();
                        }
                    } else {
                        BET /= 2;
                        btn_deal.setText(BET + " point");
                        tv_bet.setText("BET : " + BET + "");
                        btn_betFlag = true;
                        btn_bet.setText("加注BET*2");
                    }

                } else {
                    if (lpoint >= BET ) {
                        lpoint = lpoint - BET;
                        apply_point_score();
                        tv_point.setText("POINT : " + lpoint + "");

                        //====================================
                        String url = geturl("setcoin", new String[]{"id", id, "coin", lpoint + ""});
                        System.out.println(url);
                        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {

                            }
                        }, new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                System.out.println("========改錢出問題=========");
                            }

                        });

                        RequestQueue queue = Volley.newRequestQueue(MainActivitycardgame.this);
                        queue.add(stringRequest);

                        BET *= 2;
                        nw_game.playerHit();
                        IV_player3.setVisibility(View.VISIBLE);
                        card_animation(IV_player3);
                        btn_hit.setVisibility(View.GONE);
                        btn_bet.setVisibility(View.INVISIBLE);
                        btn_stand.setVisibility(View.GONE);
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                tv_player_score.setText("Player Score : " + nw_game.getPlayerScore() + "");
                                btn_hit_color(nw_game.getPlayerScore());
                                btn_hit.setEnabled(true);
                                IV_player3.setImageResource(nw_game.get_card_image(nw_game.playerCards.get(2)));
                                if (nw_game.isPlayerBust()){
                                    judgement();
                                }else{
                                    stand();
                                }
                            }
                        }, 500);
                    } else {
                        charge();
                    }
                }
            }
        });

        btn_deal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    deal();
            }
        });

        btn_hit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hit();
            }
        });
        btn_stand.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btn_bet.setVisibility(View.INVISIBLE);
                stand();

            }
        });


    }

    private void btn_hit_color(int PlayerScore) {
        if (PlayerScore == 21) {
            btn_hit.setBackgroundColor(0x80ADADAD);
            btn_hit.setTextColor(0xff000000);
        } else {
            btn_hit.setBackgroundColor(0x80ff6666);
            btn_hit.setTextColor(0xffffffff);
        }
    }

    private void deal() {
        if (!game_is_start) {
            if (lpoint >= BET) {
                lpoint = lpoint - BET;
                btn_bet.setVisibility(View.INVISIBLE);
                tv_point.setText("POINT : " + lpoint + "");
                apply_point_score();
                nw_game.dealInitialCards();

                //====================================
                String url = geturl("setcoin", new String[]{"id", id, "coin", lpoint + ""});
                System.out.println(url);
                StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        System.out.println("========改錢出問題=========");
                    }

                });

                RequestQueue queue = Volley.newRequestQueue(MainActivitycardgame.this);
                queue.add(stringRequest);

//             IV_player1.setImageResource(nw_game.IV_card.get(nw_game.playerCards.get(0)));
//             IV_dealer1.setImageResource(nw_game.IV_card.get(nw_game.dealerCards.get(0)));
//             IV_player2.setImageResource(nw_game.IV_card.get(nw_game.playerCards.get(1)));
//             IV_dealer2.setImageResource(nw_game.IV_card.get(nw_game.dealerCards.get(1)));
//            IV_dealer1.setImageResource(nw_game.get_card_image(nw_game.dealerCards.get(0)));
                IV_player1.setVisibility(View.VISIBLE);
                card_animation(IV_player1);
                btn_deal.setVisibility(View.GONE);
                new Handler().postDelayed(runnable, 500);
//             Log.d("p1", "IV_card: " + nw_game.IV_card.get(nw_game.playerCards.get(0)));
//             Log.d("p1", "card_club1 :"+ R.drawable.clubs_1);
//             btn_deal.setBackgroundResource(R.color.mycolor);

                btn_deal.setBackgroundColor(0x80ff6666);
            } else {
                charge();
            }
        } else {
            game_is_start = false;
            BET = sharedPreferences.getInt("BET", 50);
            btn_deal.setText(BET + " point");
            game_restart();
            btn_deal.setBackgroundColor(0x804466ff);
        }
    }

    private void judgement() {
        if (nw_game.isGameEnd()) {
            if (nw_game.isPlayerBust()) {
                IV_dealer1.setImageResource(nw_game.get_card_image(nw_game.dealerCards.get(0)));
                IV_dealer1.setVisibility(View.VISIBLE);
                tv_dealer_score.setText("Dealer Score : " + nw_game.getDealerScore() + "");
                tv_player_score.setText("Player Score : " + nw_game.getPlayerScore() + " Burst");
                score -= BET / 10;
                Toast.makeText(this, "You Lose!!", Toast.LENGTH_SHORT).show();

                String url = geturl("addlose", new String[]{"id", id});
                System.out.println(url);
                StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        System.out.println("========加敗場出問題=========");
                    }

                });

                RequestQueue queue = Volley.newRequestQueue(MainActivitycardgame.this);
                queue.add(stringRequest);

                apply_point_score();
                game_set();
            } else if (nw_game.playerCards.size() == 5) {
                stand();
            }
        }
        btn_hit_color(nw_game.getPlayerScore());
    }

    private void stand() {
        game_is_set=true;
        int count = 0;
        btn_stand.setVisibility(View.GONE);
        btn_hit.setVisibility(View.GONE);
        IV_dealer1.setImageResource(nw_game.get_card_image(nw_game.dealerCards.get(0)));
        IV_dealer1.setVisibility(View.VISIBLE);
        tv_dealer_score.setText("Dealer Score : " + nw_game.getDealerScore() + "");
        while (!(nw_game.getDealerScore() >= 17 || nw_game.dealerCards.size() == 5)) {
            nw_game.dealerHit();
            count++;
        }
        if(BET>=2000){
            while (nw_game.getDealerScore()<nw_game.getPlayerScore() && !(nw_game.dealerCards.size() == 5)){
                nw_game.dealerHit();
                count++;
            }
        }
        if (count >= 1) {
            IV_dealer3.setImageResource(nw_game.get_card_image(nw_game.dealerCards.get(2)));
            IV_dealer3.setVisibility(View.VISIBLE);
            card_animation(IV_dealer3);
        }
        for (int i = 0; i <= count; i++) {
            int finalI = i;
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (finalI == 3) {
                        IV_dealer5.setImageResource(nw_game.get_card_image(nw_game.dealerCards.get(4)));
                        IV_dealer5.setVisibility(View.VISIBLE);
                        card_animation(IV_dealer5);
                    } else if (finalI == 2) {
                        IV_dealer4.setImageResource(nw_game.get_card_image(nw_game.dealerCards.get(3)));
                        IV_dealer4.setVisibility(View.VISIBLE);
                        card_animation(IV_dealer4);
                    }

                }
            }, 500);
        }
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                tv_dealer_score.setText("Score : " + nw_game.getDealerScore() + "");
                if (nw_game.isPlayerWin()) {
                    Toast.makeText(MainActivitycardgame.this, "You Win!!", Toast.LENGTH_SHORT).show();
                    String url = geturl("addwin", new String[]{"id", id});
                    System.out.println(url);
                    StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            System.out.println("========加勝率出問題=========");
                        }

                    });

                    RequestQueue queue = Volley.newRequestQueue(MainActivitycardgame.this);
                    queue.add(stringRequest);

                    tv_point.setText("POINT : " + lpoint + "\t+\t" + BET * 2);
                    lpoint = lpoint + BET + BET;
                    if (nw_game.getPlayerScore() == 21) {
                        if (nw_game.playerCards.size() == 2) {
                            tv_point.append("*2");
                            lpoint = lpoint + BET * 2;
                            score += (BET / 5 * 3);
                        } else {
                            tv_point.append("*1.5");
                            lpoint = lpoint + BET;
                            score += (BET / 5 * 2);
                        }

                    } else {
                        score += BET / 5;
                    }
                    apply_point_score();
                    game_set();
                } else if (nw_game.isDealerWin()) {
                    Toast.makeText(MainActivitycardgame.this, "You Lose!!", Toast.LENGTH_SHORT).show();

                    String url = geturl("addlose", new String[]{"id", id});
                    System.out.println(url);
                    StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            System.out.println("========加敗場出問題=========");
                        }

                    });

                    RequestQueue queue = Volley.newRequestQueue(MainActivitycardgame.this);
                    queue.add(stringRequest);

                    score -= BET / 10;
                    apply_point_score();
                    game_set();
                } else {
                    Toast.makeText(MainActivitycardgame.this, "Draw!!", Toast.LENGTH_SHORT).show();

                    String url = geturl("adddraw", new String[]{"id", id});
                    System.out.println(url);
                    StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            System.out.println("========加平手出問題=========");
                        }

                    });

                    RequestQueue queue = Volley.newRequestQueue(MainActivitycardgame.this);
                    queue.add(stringRequest);

                    tv_point.setText("POINT : " + lpoint + "\t+\t" + BET);
                    score += BET / 10;
                    lpoint = lpoint + BET;
                    apply_point_score();
                    game_set();
                }
            }
        }, 500 * (count + 1));

    }

    private void game_set() {
        //不讓user使用的元件，先無效化
        game_is_set=true;
        btn_stand.setVisibility(View.GONE);
        btn_hit.setVisibility(View.GONE);
        btn_deal.setVisibility(View.VISIBLE);
        if (game_is_start) {
            tv_point.setText("POINT : " + lpoint + "");
        }
    }

    private void game_restart() {
        change_cardback();
        nw_game.dealerCards.clear();
        nw_game.playerCards.clear();
        if (nw_game.deck.size() < 10) {
            nw_game = new game();
        }
        tv_dealer_score.setText("Dealer Score : 0");
        tv_player_score.setText("Player Score : 0");
        tv_bet.setText("BET : " + BET + "");
        btn_betFlag = true;
        btn_bet.setText("加注BET*2");
        btn_bet.setVisibility(View.VISIBLE);
        game_is_set=false;
    }

    private void card_animation(ImageView imageview) {
        // 计算 ImageView 的起始位置和结束位置
        int startX = layout_game.getWidth();
        int endX = imageview.getLeft();
        // 创建 TranslateAnimation 对象
        TranslateAnimation animation = new TranslateAnimation(startX, endX, 0, 0);
        // 设置动画持续时间和重复次数
        animation.setDuration(500);
        animation.setRepeatCount(0);
        animation.setInterpolator(new DecelerateInterpolator());
        // 启动动画
        imageview.startAnimation(animation);
    }

    //deal card animation
    Runnable runnable = new Runnable() {
        @Override
        public void run() {
            IV_dealer1.setVisibility(View.VISIBLE);
            card_animation(IV_dealer1);
            IV_player1.setImageResource(nw_game.get_card_image(nw_game.playerCards.get(0)));
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    IV_player1.setImageResource(nw_game.get_card_image(nw_game.playerCards.get(0)));
                    IV_player2.setVisibility(View.VISIBLE);
                    card_animation(IV_player2);
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            IV_dealer2.setVisibility(View.VISIBLE);
                            card_animation(IV_dealer2);
                            IV_player2.setImageResource(nw_game.get_card_image(nw_game.playerCards.get(1)));
                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    IV_dealer2.setImageResource(nw_game.get_card_image(nw_game.dealerCards.get(1)));
                                    tv_player_score.setText("Player Score : " + nw_game.getPlayerScore() + " ");
                                    tv_dealer_score.setText("Dealer Score : ？+ " + nw_game.dealerCards.get(1).getValue() + "");
                                    btn_stand.setVisibility(View.VISIBLE);
                                    btn_hit_color(nw_game.getPlayerScore());
                                    btn_hit.setVisibility(View.VISIBLE);
                                    btn_deal.setText("Reset");
                                    if (nw_game.getPlayerScore() >= 11) {
                                        btn_bet.setText("Final Hit BET*2");
                                        btn_bet.setVisibility(View.VISIBLE);
                                    }
                                    game_is_start = true;
                                }
                            }, 500);
                        }
                    }, 500);
                }
            }, 500);
        }
    };

    private void charge() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("提示")
                .setMessage("要前往商城嗎？")
                .setPositiveButton("前往", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // 点击确定按钮后的处理逻辑
                        Intent it = new Intent(MainActivitycardgame.this, MainActivityshop.class);
                        startActivity(it);
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    public void getUserpoint(String uid, final OnUserpointCallback callback) {
        uref.child(uid).child("point").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                int point = snapshot.getValue(Integer.class);
                callback.onUserpoint(point);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                callback.onUserpoint(0);
            }
        });
    }

    public interface OnUserpointCallback {
        void onUserpoint(int point);
    }


    public void apply_point_score() {
        uref.child(uid).child("point").setValue(lpoint);
        uref.child(uid).child("score").setValue(score);
        editor.putInt("point", lpoint);
        editor.putInt("score", score);
        editor.apply();

        String url = geturl("setcoin", new String[]{"id", id, "coin", lpoint + ""});
        System.out.println(url);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                System.out.println("========改錢出問題=========");
            }

        });

        RequestQueue queue = Volley.newRequestQueue(MainActivitycardgame.this);
        queue.add(stringRequest);

        url = geturl("setscore", new String[]{"id", id, "number", score + ""});
        System.out.println(url);
        stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                System.out.println("========改分數出問題=========");
            }

        });

        queue = Volley.newRequestQueue(MainActivitycardgame.this);
        queue.add(stringRequest);
    }

    private String geturl(String action, String[] input) {
        String outurl = ogurl + "?action=" + action;
        for (int i = 0; i < input.length; i += 2) {
            outurl = outurl + "&" + input[i] + "=" + input[i + 1];
        }

        return outurl;
    }

    //Double Tap
    class MyGestureListener extends GestureDetector.SimpleOnGestureListener{
        @Override
        public boolean onDoubleTap(MotionEvent e) {
            Log.d(">>>", "onDoubleTap");
            if(game_is_start && !game_is_set){
                hit();
            }
            return true;
        }

        @Override
        public boolean onDown(MotionEvent e) {
            return true;
        }
    }
    private void hit(){
        game_is_start=false;
        btn_bet.setVisibility(View.INVISIBLE);
        nw_game.playerHit();
        btn_hit.setEnabled(false);
        if (nw_game.playerCards.size() == 5) {
            IV_player5.setVisibility(View.VISIBLE);
            card_animation(IV_player5);
        } else if (nw_game.playerCards.size() == 4) {
            IV_player4.setVisibility(View.VISIBLE);
            card_animation(IV_player4);
        } else if (nw_game.playerCards.size() == 3) {
            IV_player3.setVisibility(View.VISIBLE);
            card_animation(IV_player3);
        }
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                tv_player_score.setText("Player Score : " + nw_game.getPlayerScore() + "");
                btn_hit_color(nw_game.getPlayerScore());
                judgement();
                btn_hit.setEnabled(true);
                if (nw_game.playerCards.size() == 5) {
                    IV_player5.setImageResource(nw_game.get_card_image(nw_game.playerCards.get(4)));
                } else if (nw_game.playerCards.size() == 4) {
                    IV_player4.setImageResource(nw_game.get_card_image(nw_game.playerCards.get(3)));
                } else if (nw_game.playerCards.size() == 3) {
                    IV_player3.setImageResource(nw_game.get_card_image(nw_game.playerCards.get(2)));
                }
                game_is_start=true;
            }
        }, 500);
    }

    private void change_cardback(){
        IV_player1.setVisibility(View.INVISIBLE);
        IV_player1.setImageResource(card_list.get((char) card_used));
        IV_player2.setVisibility(View.INVISIBLE);
        IV_player2.setImageResource(card_list.get((char) card_used));
        IV_player3.setVisibility(View.INVISIBLE);
        IV_player3.setImageResource(card_list.get((char) card_used));
        IV_player4.setVisibility(View.INVISIBLE);
        IV_player4.setImageResource(card_list.get((char) card_used));
        IV_player5.setVisibility(View.INVISIBLE);
        IV_player5.setImageResource(card_list.get((char) card_used));
        IV_dealer1.setVisibility(View.INVISIBLE);
        IV_dealer1.setImageResource(card_list.get((char) card_used));
        IV_dealer2.setVisibility(View.INVISIBLE);
        IV_dealer2.setImageResource(card_list.get((char) card_used));
        IV_dealer3.setVisibility(View.INVISIBLE);
        IV_dealer3.setImageResource(card_list.get((char) card_used));
        IV_dealer4.setVisibility(View.INVISIBLE);
        IV_dealer4.setImageResource(card_list.get((char) card_used));
        IV_dealer5.setVisibility(View.INVISIBLE);
        IV_dealer5.setImageResource(card_list.get((char) card_used));
    }


    @Override
    protected void onResume() {
        super.onResume();
        card_used = sharedPreferences.getInt("card_used", 'A');
        table_used = sharedPreferences.getInt("table_used", 'A');
        layout_game.setBackgroundResource(table_list.get((char) table_used));
        if(!game_is_start){
            change_cardback();
        }
        getUserpoint(uid, new OnUserpointCallback() {
            @Override
            public void onUserpoint(int point) {
                lpoint = point;
                tv_point.setText("POINT : " + lpoint + "");
            }
        });
    }
}