//package com.example.ex_4;
//
//import static android.service.controls.ControlsProviderService.TAG;
//
//import androidx.annotation.NonNull;
//import androidx.appcompat.app.AppCompatActivity;
//
//import android.content.Intent;
//import android.os.Bundle;
//import android.util.Log;
//import android.view.View;
//import android.widget.Button;
//import android.widget.CheckBox;
//import android.widget.EditText;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import com.google.android.gms.tasks.OnCompleteListener;
//import com.google.android.gms.tasks.Task;
//import com.google.firebase.auth.AuthResult;
//import com.google.firebase.auth.FirebaseAuth;
//import com.google.firebase.auth.FirebaseAuthUserCollisionException;
//import com.google.firebase.auth.FirebaseUser;
//import com.google.firebase.database.DatabaseReference;
//import com.google.firebase.database.FirebaseDatabase;
//
//public class MainActivity1 extends AppCompatActivity {
//
//    private EditText edittext_name, edittext_email, edittext_other, edittext_passwd;
//    private TextView textview_result;
//    private Button button_cancel, button_ok;
//    DatabaseReference databaseRef = FirebaseDatabase.getInstance().getReference();
//    FirebaseAuth mAuth = FirebaseAuth.getInstance();
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main1);
//
//        edittext_name = (EditText) findViewById(R.id.editTextPersonName);
//        edittext_email = (EditText) findViewById(R.id.editTextTextEmailAddress);
//        edittext_passwd = findViewById(R.id.Password);
//
//        textview_result = (TextView) findViewById(R.id.textView_result);
//        textview_result.setText("");
//
//        button_cancel = (Button) findViewById(R.id.button_cancel);
//        button_ok = (Button) findViewById(R.id.button_ok);
//
//        button_cancel.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                edittext_name.setText("");
//                edittext_email.setText("");
//                edittext_other.setText("");
//                textview_result.setText("");
//                Intent it = new Intent(MainActivity1.this, LoginActivity.class);
//                startActivity(it);
//            }
//        });
//        button_ok.setOnClickListener(new ButtonOK());
//    }
//
//    private class ButtonOK implements View.OnClickListener {
//        @Override
//        public void onClick(View v) {
//            textview_result.setText("");
//            String name = edittext_name.getText().toString();
//            String email = edittext_email.getText().toString();
//            String str_other = edittext_other.getText().toString();
//            String passwd = edittext_passwd.getText().toString();
//            if (name.length() == 0 && email.length() == 0) {
//                edittext_name.setHint("請輸入姓名");
//                edittext_email.setHint("請輸入E-mail");
//            } else if (passwd.length() == 0) {
//                Toast.makeText(MainActivity1.this, "請輸入密碼", Toast.LENGTH_SHORT).show();
//            }
////            else if(!(checkbox_sport.isChecked()||checkbox_read.isChecked()||checkbox_painting.isChecked()||checkbox_other.isChecked()||checkbox_swim.isChecked())){
////                Toast.makeText(MainActivity.this, "請選擇一種興趣，或勾選其他並輸入您的興趣", Toast.LENGTH_SHORT).show();
////            }
////            else if (checkbox_other.isChecked()&&str_other.length()==0) {
////                Toast.makeText(MainActivity.this, "請輸入您的興趣，或勾選一種興趣", Toast.LENGTH_SHORT).show();
////            }
//            else {
//                textview_result.setText("姓名:" + name + " 密碼:" + passwd + " E-mail:" + email + "\n");
////                textview_result.append("你的興趣是：\n");
////                if(checkbox_sport.isChecked()) textview_result.append("運動 ");
////                if(checkbox_read.isChecked()) textview_result.append("閱讀 ");
////                if(checkbox_painting.isChecked()) textview_result.append("繪畫 ");
////                if (checkbox_swim.isChecked()) textview_result.append("游泳 ");
////                if(checkbox_other.isChecked()) textview_result.append(edittext_other.getText().toString()+"");
//
//                mAuth.createUserWithEmailAndPassword(email, passwd).addOnCompleteListener(MainActivity1.this, new OnCompleteListener<AuthResult>() {
//                    @Override
//                    public void onComplete(@NonNull Task<AuthResult> task) {
//                        if (task.isSuccessful()) {
//                            // 註冊成功
//                            Log.d(TAG, "createUserWithEmail:success");
//                            FirebaseUser user = mAuth.getCurrentUser();
//                            // 創建一個新的使用者節點
//                            String uid = user.getUid();
//                            DatabaseReference userRef = databaseRef.child("userinfo").child(uid);
//
//                            // 在該節點中存儲使用者資訊
//                            userRef.child("email").setValue(email);
//                            userRef.child("name").setValue(name);
//                            userRef.child("passwd").setValue(passwd);
//                            userRef.child("point").setValue(20000);
//                            userRef.child("card_have").setValue("A");
//                            userRef.child("table_have").setValue("A");
//                            userRef.child("score").setValue(0);
//
//                            user.sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
//                                @Override
//                                public void onComplete(@NonNull Task<Void> task) {
//                                    if (task.isSuccessful()) {
//                                        // 驗證郵件發送成功
//                                        Toast.makeText(getApplicationContext(), "Verification email sent to " + mAuth.getCurrentUser().getEmail(), Toast.LENGTH_SHORT).show();
//                                        Intent it = new Intent(MainActivity1.this, LoginActivity.class);
//                                        it.putExtra("Email", email);
//                                        startActivity(it);
//                                    } else {
//                                        // 驗證郵件發送失敗
//                                        Toast.makeText(getApplicationContext(), "Failed to send verification email.", Toast.LENGTH_SHORT).show();
//                                    }
//                                }
//                            });
//                        } else {
//                            // 註冊失敗
//                            Exception e = task.getException();
//                            Log.w(TAG, "createUserWithEmail:failure", e);
//                            if (e instanceof FirebaseAuthUserCollisionException) {
//                                // 該使用者已經存在
//                                Toast.makeText(MainActivity1.this, "該使用者已經存在", Toast.LENGTH_SHORT).show();
//                            } else {
//                                // 其他錯誤
//                                Toast.makeText(MainActivity1.this, "註冊失敗，請詢問管理者", Toast.LENGTH_SHORT).show();
//                            }
//                        }
//                    }
//                });
//
//            }
//
//        }
//
//    }
//}