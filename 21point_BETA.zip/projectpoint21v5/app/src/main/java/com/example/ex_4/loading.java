package com.example.ex_4;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.Window;
import android.widget.ProgressBar;
public class loading {
    Dialog loading;
    loading(Context activity){
        loading = new Dialog(activity);
        loading.setContentView(R.layout.dialog_loading);
        Window window = loading.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        ProgressBar progressBar = loading.findViewById(R.id.progressBar);
        loading.setCancelable(false); // 禁止使用者點擊螢幕關閉這個Dialog
        loading.show();
    }
    public void finish(){
        loading.dismiss();
    }
}
