package com.example.ex_4;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import com.example.ex_4.MainActivity;

public class LoginActivity extends AppCompatActivity {
    private static final String TAG = "LoginActivity";

    private EditText mEmailField;
    private EditText mPasswordField;
    private Button mLoginButton,button_submit,btn_rank;
    private static final int PICK_IMAGE_REQUEST = 1,EDIT_IMAGE_REQUEST=50;
//    private FirebaseAuth mAuth;
    private View button_re;
    DatabaseReference database = FirebaseDatabase.getInstance().getReference();
    String  uid ,name;
    DatabaseReference udata = database.child("userinfo");
    FirebaseStorage storage = FirebaseStorage.getInstance();
    StorageReference storageRef = storage.getReference();
    private ImageView ImageView_photo;
    StorageReference userRef;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // 初始化 FirebaseAuth 實例
//        mAuth = FirebaseAuth.getInstance();

        sharedPreferences = getSharedPreferences("my_prefs", Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();

        Intent it = getIntent();
        String Email = it.getStringExtra("Email");
        // 綁定元件
        ImageView_photo = (ImageView)findViewById(R.id.ImageView_photo);
        //照片
        ImageView_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.setType("image/*");
                startActivityForResult(intent, PICK_IMAGE_REQUEST);
            }
        });
        mEmailField = findViewById(R.id.email_field);
        if (Email!=""){
            mEmailField.setText(Email);
        }
        mPasswordField = findViewById(R.id.password_field);
        mLoginButton = findViewById(R.id.login_button);
        button_re = findViewById(R.id.button_re);
        button_re.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                mAuth.getCurrentUser().sendEmailVerification();
            }
        });

        button_submit = findViewById(R.id.button_submit);
        button_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editor.remove("is_login").apply();
            }
        });
        btn_rank = findViewById(R.id.button_rank);
        btn_rank.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(LoginActivity.this,RankActivity.class);
                startActivity(it);
            }
        });
        // 設定按鈕監聽事件
        mLoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = mEmailField.getText().toString();
                String password = mPasswordField.getText().toString();
                // 認證使用者
//                mAuth.signInWithEmailAndPassword(email, password)
//                        .addOnCompleteListener(LoginActivity.this, new OnCompleteListener<AuthResult>() {
//                            @Override
//                            public void onComplete(@NonNull Task<AuthResult> task) {
//                                if (task.isSuccessful()) {
//                                    FirebaseUser user =mAuth.getCurrentUser();
//                                    uid = user.getUid();
//                                    if (user != null && user.isEmailVerified()) {
//                                        // 登錄成功，且用戶已通過電子郵件驗證
//                                        Log.d(TAG, "signInWithEmail:success");
//                                        udata.child(uid).child("name").addListenerForSingleValueEvent(new ValueEventListener() {
//                                            @Override
//                                            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                                                name = snapshot.getValue(String.class);
//                                                Toast.makeText(LoginActivity.this, "登入成功\nWelcome back "+ name, Toast.LENGTH_SHORT).show();
//                                            }
//
//                                            @Override
//                                            public void onCancelled(@NonNull DatabaseError error) {
//                                                Log.w(TAG, "Failed to read value.", error.toException());
//                                            }
//                                        });
//                                        Log.d("userID",uid);
//                                        mEmailField.setText("");
//                                        mPasswordField.setText("");
//                                        button_submit.setVisibility(View.VISIBLE);
//                                        userRef = storageRef.child(uid);
//                                        StorageReference imageRef = userRef.child("image.png");
//                                        try {
//                                            File localFile = File.createTempFile("image", "png");
//                                            imageRef.getFile(localFile).addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
//                                                @Override
//                                                public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
//                                                    // 下載成功，將圖片顯示在ImageView中
//                                                    show_image(localFile);
//                                                }
//                                            }).addOnFailureListener(new OnFailureListener() {
//                                                @Override
//                                                public void onFailure(@NonNull Exception exception) {
//                                                    // 下載失敗，輸出錯誤訊息
//                                                    Log.e("TAG", "下載失敗：" + exception.getMessage());
////                                                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
////                                                    intent.setType("image/*");
////                                                    startActivityForResult(intent, PICK_IMAGE_REQUEST);
//
//                                                    storageRef.child("userdefault.jpg").getFile(localFile).addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
//                                                        @Override
//                                                        public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
//                                                            // 下載成功，將圖片顯示在ImageView中
//                                                            Log.d("TAG","success");
//                                                            show_image(localFile);
//                                                        }
//                                                    }).addOnFailureListener(new OnFailureListener() {
//                                                        @Override
//                                                        public void onFailure(@NonNull Exception exception) {
//                                                            // 下載失敗，輸出錯誤訊息
//                                                            Log.e("TAG","fail");
//                                                        }
//                                                    });
//
//
//                                                }
//                                            });
//                                        } catch (IOException e) {
//                                            // 輸出錯誤訊息
//                                            e.printStackTrace();
//                                        }
//
//                                    } else {
//                                        // 登錄成功，但用戶未通過電子郵件驗證
//                                        Toast.makeText(LoginActivity.this, "請至註冊信箱收信", Toast.LENGTH_SHORT).show();
//                                        button_re.setVisibility(View.VISIBLE);
//                                    }
//
//                                } else {
//                                    // 登入失敗，顯示錯誤信息
//                                    Log.w(TAG, "signInWithEmail:failure", task.getException());
//                                    Toast.makeText(LoginActivity.this, "登入失敗，請檢查帳號密碼是否正確", Toast.LENGTH_SHORT).show();
//                                }
//                            }
//                        });
            }
        });

        String fileName = "image.png";
        File file = new File(getFilesDir(), fileName);
        if (file.exists()) {
            Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
            ImageView_photo.setImageBitmap(bitmap);
        }else{
            Log.d(TAG, "file no exists");
        }


    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        uid = sharedPreferences.getString("uid","");
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            Log.d(TAG, uid);
            StorageReference imageRef = FirebaseStorage.getInstance().getReference().child(uid).child("image.png");
            if (imageRef != null) {
            try {
                // 讀取原始圖片
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), uri);

                // 計算壓縮比例，以實現圖片大小小於 300*300
                int width = bitmap.getWidth();
                int height = bitmap.getHeight();
                int maxSize = Math.max(width, height);
                float ratio = maxSize / 400.0f;

                // 調整圖片大小，寬高比保持不變
                int newWidth = (int) (width / ratio);
                int newHeight = (int) (height / ratio);
                Bitmap resizedBitmap = Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, true);

                // 壓縮圖片，將品質設為70%
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                resizedBitmap.compress(Bitmap.CompressFormat.PNG, 70, baos);
                byte[] bytes = baos.toByteArray();

                // 上傳圖片，bytes是壓縮後的圖片數據
                UploadTask uploadTask = imageRef.putBytes(bytes);
                uploadTask.addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        // 上傳成功
                        Toast.makeText(LoginActivity.this, "update success", Toast.LENGTH_SHORT).show();
                        try {
                            File localFile = File.createTempFile("image", "png");
                            String fileName = "image.png";
                            createimage(fileName,localFile);
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }


                        // 讀取圖片並顯示在ImageView中
                        ImageView_photo.setImageBitmap(resizedBitmap);
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception exception) {
                        // 上傳失敗
                        Toast.makeText(LoginActivity.this, "update fail", Toast.LENGTH_SHORT).show();
                    }
                });



            } catch (IOException e) {
                e.printStackTrace();
            }
        }else {
                Log.d("no image", "no image");
            }
        }
    }
    void show_image(File localFile){
        Bitmap bitmap = BitmapFactory.decodeFile(localFile.getAbsolutePath());
        ImageView_photo.setImageBitmap(bitmap);
    }
//    @Override
//    protected void onResume() {
//        super.onResume();
//
//        // 從本地文件系統中讀取圖像文件，創建位圖
//        String fileName = "image.png";
//        File file = new File(getFilesDir(), fileName);
//        if (file.exists()) {
//            Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
//
//            // 將位圖設置為 ImageView 的圖像
//            ImageView_photo.setImageBitmap(bitmap);
//        } else {
//            Log.d(TAG, "file no exists");
//        }
//    }
    public void createimage(String fileName, File content) {
        try {
            FileOutputStream outputStream = openFileOutput(fileName, Context.MODE_PRIVATE);
            InputStream inputStream = new FileInputStream(content);
            byte[] buffer = new byte[1024];
            int length;
            while ((length = inputStream.read(buffer)) > 0) {
                outputStream.write(buffer, 0, length);
            }
            inputStream.close();
            outputStream.close();
            Log.i("TAG", "File saved successfully.");
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
