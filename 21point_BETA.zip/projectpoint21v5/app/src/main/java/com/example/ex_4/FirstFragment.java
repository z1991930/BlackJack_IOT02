package com.example.ex_4;


import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import java.util.ArrayList;




/**
 * A simple {@link Fragment} subclass.
 */
class itemc {

    public int index;

    public String cardname;

    public String carddetail;
    public int picture;
    public int cost;
    public LinearLayout itemlinearLayout;
    public TextView itemtextView;
    public TextView itemtitleView;
    public itemc(){

    }

}
public class FirstFragment extends Fragment {

    private String usingdata = "lgdiot02";

    private int giftmoney = 1000;
    private TextView itemText;

    private ArrayList<itemc> itempList = new ArrayList<>();

    private Dialog dialog;

    private Toast toast;

    private MySharedViewModel sharedViewModel;

    public void setSharedViewModel(MySharedViewModel viewModel) {
        sharedViewModel = viewModel;
    }

    public FirstFragment() {
        // Required empty public constructor
    }


    @SuppressLint({"MissingInflatedId", "SetTextI18n"})
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        sharedViewModel = new ViewModelProvider(requireActivity()).get(MySharedViewModel.class);

        // 獲取usermoney參數的值
        sharedViewModel.getUserMoney().observe(getViewLifecycleOwner(), money -> {
            // 更新UI
            usermoney = money;
        });

        usermoney = sharedViewModel.getUserMoney().getValue();

//==============================================================================================================
        View view = inflater.inflate(R.layout.fragment_first, container, false);
        TextView textword = view.findViewById(R.id.secretline);
        TextView[] copytext = {view.findViewById(R.id.item_text1),view.findViewById(R.id.item_text2)
                ,view.findViewById(R.id.item_text3),view.findViewById(R.id.item_text4)
                ,view.findViewById(R.id.item_text5),view.findViewById(R.id.item_text6)};

        TextView[] copytitle = {view.findViewById(R.id.item_title),view.findViewById(R.id.item_title2)
                ,view.findViewById(R.id.item_title3),view.findViewById(R.id.item_title4)
                ,view.findViewById(R.id.item_title5),view.findViewById(R.id.item_title6)};

        LinearLayout[] copylinearLayout = {view.findViewById(R.id.layoutp1),view.findViewById(R.id.layoutp2)
                ,view.findViewById(R.id.layoutp3),view.findViewById(R.id.layoutp4)
                ,view.findViewById(R.id.layoutp5),view.findViewById(R.id.layoutp6)};

        ImageView[] item_image = {  view.findViewById(R.id.item_image),view.findViewById(R.id.item_image2),
                                    view.findViewById(R.id.item_image3),view.findViewById(R.id.item_image4),
                                    view.findViewById(R.id.item_image5),view.findViewById(R.id.item_image6)};

        int[] copydrawable = {R.drawable.coin,R.drawable.coin,R.drawable.coin,R.drawable.coin,R.drawable.coin,R.drawable.yellowbox};
        String[] cointd = {"NT$ 50","NT$ 120","NT$ 400","NT$ 1900","NT$ 2980","Free"} ;
        int[] coinpoint = {200,600,2400,12000,21000,1000};
        String[] copyCardName = {"一枚代幣","一疊代幣","一盒代幣","一桶代幣","一箱代幣","禮物"};
        String[] copyCarddetail = { "暫不提供兌幣服務",
                "暫不提供兌幣服務",
                "暫不提供兌幣服務",
                "暫不提供兌幣服務",
                "暫不提供兌幣服務",
                "只有有需要的人才可以領取"};
//==============================================================================================================


        for(int i = 0 ; i < 6 ; i++ ){
            Drawable green = ContextCompat.getDrawable(requireContext(), R.drawable.greenborder);
            Drawable white = ContextCompat.getDrawable(requireContext(), R.drawable.whiteborder);
            itemc item = new itemc();
            item.itemtextView = copytext[i];
            item.itemtextView.setText(cointd[i]);
            item.itemlinearLayout = copylinearLayout[i];
            item.picture = copydrawable[i];
            item.cardname = copyCardName[i];
            item.carddetail = copyCarddetail[i];
            item_image[i].setImageResource(copydrawable[i]);
            item.itemtextView.setTextColor(0xFFFFFFFF);
            item.itemtitleView = copytitle[i];
            item.itemtitleView.setText(coinpoint[i]+"p");

            item.cost = coinpoint[i] ;
            String c = i+"";

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                    item.itemlinearLayout.setBackground(white);
                }

                if(i==5 && usermoney < 100){
                    System.out.println("+++"+usermoney);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                        item.itemlinearLayout.setBackground(green);
                    }

                }

            int finalI = i;
            sharedViewModel.getUserMoney().observe(getViewLifecycleOwner(), money -> {
                // 更新UI
                if(finalI ==5 && money < giftmoney){
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                        item.itemlinearLayout.setBackground(green);
                    }

                }
                else{
                    item.itemlinearLayout.setBackground(white);
                }
            });


            item.index = i;
            itempList.add(item);
        }


        dialog = new Dialog(this.getActivity());

        for(int i = 0 ; i < 6 ; i++ ){
            final int finalI = i;
            itempList.get(i).itemlinearLayout.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
//                            System.out.println("I get : " + textword.getText().toString());
//                             System.out.println("you need : " + usingdata );

                            if( textword.getText().toString().equals(usingdata)  ){

                                if (toast != null) {
                                    toast.cancel();
                                }

                                if(finalI == 5 ){
                                    toast = Toast.makeText( getActivity(), "已關閉", Toast.LENGTH_SHORT);
                                    toast.show();
                                }
                                else{
                                usermoney = usermoney + itempList.get(finalI).cost;
                                sharedViewModel.setUserMoney(usermoney);

                                toast = Toast.makeText( getActivity(), "已發送", Toast.LENGTH_SHORT);
                                toast.show();
                                }
                            }
                            else if( finalI == 4 && ((usermoney%50)==0)){ // 小額補助彩蛋
                                dialog.setContentView(R.layout.custom_dialog);
                                final TextView message = dialog.findViewById(R.id.dialog_message);
                                final TextView title = dialog.findViewById(R.id.dialog_title);
                                final TextView cost = dialog.findViewById(R.id.item_cost);
                                final ImageView icardimage = dialog.findViewById(R.id.item_image);

                                icardimage.setImageResource(itempList.get(finalI).picture);

                                Context context = getContext();
                                DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
                                float dpWidth = displayMetrics.widthPixels;
                                float dpHeight = displayMetrics.heightPixels;

                                ConstraintLayout dialogLayout = dialog.findViewById(R.id.diglog);
                                ViewGroup.LayoutParams params = dialogLayout.getLayoutParams();
                                params.width = (int) (dpWidth * 0.8);
                                params.height = (int) (dpHeight * 0.5);
                                dialogLayout.setLayoutParams(params);


                                title.setText(itempList.get(finalI).cardname);
                                message.setText("有幾枚代幣掉了出來");
                                message.setTextColor(0xFF409300);
                                cost.setText(itempList.get(finalI).cost + "p");

                                Button okButton = dialog.findViewById(R.id.dialog_ok_button);
                                okButton.setEnabled(true);
                                okButton.setVisibility(View.VISIBLE);

                                Button calcelButton = dialog.findViewById(R.id.dialog_calcelbutton);
                                calcelButton.setEnabled(true);
                                calcelButton.setVisibility(View.VISIBLE);

                                Button centerButton = dialog.findViewById(R.id.dialog_centerbutton);
                                centerButton.setEnabled(false);
                                centerButton.setVisibility(View.INVISIBLE);

                                okButton.setText("拿走");
                                calcelButton.setText("離開");

                                calcelButton.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {


                                        if (toast != null) {
                                            toast.cancel();
                                        }

                                        // 顯示新的 Toast
                                        dialog.dismiss();
                                    }
                                });

                                okButton.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {


                                        if (toast != null) {
                                            toast.cancel();
                                        }

                                        usermoney = usermoney + 40;
                                        sharedViewModel.setUserMoney(usermoney);

                                        toast = Toast.makeText(context, "你撿到4枚代幣!", Toast.LENGTH_SHORT);
                                        toast.show();
                                        // 顯示新的 Toast
                                        dialog.dismiss();
                                    }
                                });


                                dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
                                    @Override
                                    public void onCancel(DialogInterface dialog) {
                                        if (toast != null) {
                                            toast.cancel();
                                        }

                                        // 顯示新的 Toast
                                        toast = Toast.makeText(context, "失敗!", Toast.LENGTH_SHORT);
                                        //toast.show();
                                    }
                                });

                                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                                dialog.getWindow().setDimAmount(0.0f);
                                dialog.show();

                                if (toast != null) {
                                    toast.cancel();
                                }

                                // 顯示新的 Toast
                                toast = Toast.makeText(getActivity(), "你已經在使用這個卡背", Toast.LENGTH_SHORT);
                                //toast.show();
                            }
                            else if( finalI == 5 && usermoney < giftmoney ){ // 禮物箱彩蛋
                                dialog.setContentView(R.layout.custom_dialog);
                                final TextView message = dialog.findViewById(R.id.dialog_message);
                                final TextView title = dialog.findViewById(R.id.dialog_title);
                                final TextView cost = dialog.findViewById(R.id.item_cost);
                                final ImageView icardimage = dialog.findViewById(R.id.item_image);

                                icardimage.setImageResource(itempList.get(finalI).picture);

                                Context context = getContext();
                                DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
                                float dpWidth = displayMetrics.widthPixels;
                                float dpHeight = displayMetrics.heightPixels;

                                ConstraintLayout dialogLayout = dialog.findViewById(R.id.diglog);
                                ViewGroup.LayoutParams params = dialogLayout.getLayoutParams();
                                params.width = (int) (dpWidth * 0.8);
                                params.height = (int) (dpHeight * 0.5);
                                dialogLayout.setLayoutParams(params);


                                title.setText(itempList.get(finalI).cardname);
                                message.setText("需要一些幫助嗎?");
                                message.setTextColor(0xFF409300);
                                cost.setText(itempList.get(finalI).cost + "p");

                                Button okButton = dialog.findViewById(R.id.dialog_ok_button);
                                okButton.setEnabled(true);
                                okButton.setVisibility(View.VISIBLE);

                                Button calcelButton = dialog.findViewById(R.id.dialog_calcelbutton);
                                calcelButton.setEnabled(true);
                                calcelButton.setVisibility(View.VISIBLE);

                                Button centerButton = dialog.findViewById(R.id.dialog_centerbutton);
                                centerButton.setEnabled(false);
                                centerButton.setVisibility(View.INVISIBLE);

                                okButton.setText("領取");
                                calcelButton.setText("離開");

                                calcelButton.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {


                                        if (toast != null) {
                                            toast.cancel();
                                        }

                                        // 顯示新的 Toast
                                        dialog.dismiss();
                                    }
                                });

                                okButton.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {


                                        if (toast != null) {
                                            toast.cancel();
                                        }

                                        usermoney = usermoney + giftmoney;
                                        sharedViewModel.setUserMoney(usermoney);

                                        toast = Toast.makeText(context, "獲得一些點數", Toast.LENGTH_SHORT);
                                        toast.show();
                                        // 顯示新的 Toast
                                        dialog.dismiss();
                                    }
                                });


                                dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
                                    @Override
                                    public void onCancel(DialogInterface dialog) {
                                        if (toast != null) {
                                            toast.cancel();
                                        }

                                        // 顯示新的 Toast
                                        toast = Toast.makeText(context, "失敗!", Toast.LENGTH_SHORT);
                                        //toast.show();
                                    }
                                });

                                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                                dialog.getWindow().setDimAmount(0.0f);
                                dialog.show();

                                if (toast != null) {
                                    toast.cancel();
                                }

                                // 顯示新的 Toast
                                toast = Toast.makeText(getActivity(), "你已經在使用這個卡背", Toast.LENGTH_SHORT);
                                //toast.show();
                            }
                            else {  // 一般選項
                                dialog.setContentView(R.layout.custom_dialog);
                                final TextView message = dialog.findViewById(R.id.dialog_message);
                                final TextView title = dialog.findViewById(R.id.dialog_title);
                                final TextView cost = dialog.findViewById(R.id.item_cost);
                                final ImageView icardimage = dialog.findViewById(R.id.item_image);

                                icardimage.setImageResource(itempList.get(finalI).picture);

                                Context context = getContext();
                                DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
                                float dpWidth = displayMetrics.widthPixels;
                                float dpHeight = displayMetrics.heightPixels;

                                ConstraintLayout dialogLayout = dialog.findViewById(R.id.diglog);
                                ViewGroup.LayoutParams params = dialogLayout.getLayoutParams();
                                params.width = (int) (dpWidth * 0.8);
                                params.height = (int) (dpHeight * 0.5);
                                dialogLayout.setLayoutParams(params);


                                title.setText(itempList.get(finalI).cardname);
                                message.setText(itempList.get(finalI).carddetail);
                                message.setTextColor(0xFFEC5B5B);
                                cost.setText(itempList.get(finalI).cost + "p");

                                Button okButton = dialog.findViewById(R.id.dialog_ok_button);
                                okButton.setEnabled(false);
                                okButton.setVisibility(View.INVISIBLE);

                                Button calcelButton = dialog.findViewById(R.id.dialog_calcelbutton);
                                calcelButton.setEnabled(false);
                                calcelButton.setVisibility(View.INVISIBLE);

                                Button centerButton = dialog.findViewById(R.id.dialog_centerbutton);
                                centerButton.setEnabled(true);
                                centerButton.setVisibility(View.VISIBLE);

                                centerButton.setText("返回");

                                centerButton.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {


                                        if (toast != null) {
                                            toast.cancel();
                                        }

                                        // 顯示新的 Toast
                                        dialog.dismiss();
                                    }
                                });


                                dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
                                    @Override
                                    public void onCancel(DialogInterface dialog) {
                                        if (toast != null) {
                                            toast.cancel();
                                        }

                                        // 顯示新的 Toast
                                        toast = Toast.makeText(context, "失敗!", Toast.LENGTH_SHORT);
                                        //toast.show();
                                    }
                                });

                                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                                dialog.getWindow().setDimAmount(0.0f);
                                dialog.show();

                                if (toast != null) {
                                    toast.cancel();
                                }

                                // 顯示新的 Toast
                                toast = Toast.makeText(getActivity(), "你已經在使用這個卡背", Toast.LENGTH_SHORT);
                                //toast.show();
                            }


                    if( finalI == 5  ){ textword.setText("") ;}

                }
            });
        }

        return view;
    }

    public void setItemText(String text) {
        itemText.setText(text);
    }


    private int usermoney = 0;
}