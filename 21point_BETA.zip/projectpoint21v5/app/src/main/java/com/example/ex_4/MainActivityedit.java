package com.example.ex_4;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class MainActivityedit extends AppCompatActivity {

    private ImageButton signout;
    private ImageView messageeditButton, nameButton, imagephoto;
    private TextView messageoutputText, messagepoint;
    private EditText namemessage;

    private String ogurl,id;
    private boolean nameeditable = false;
    private static final int PICK_IMAGE_REQUEST = 1, EDIT_IMAGE_REQUEST = 50;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    String uid, name, message;
    int point;
    DatabaseReference database = FirebaseDatabase.getInstance().getReference().child("userinfo");
    private TextView messageWLD,winrate;
    private TextView scoremessage;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mainedit);

        sharedPreferences = getSharedPreferences("my_prefs", Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
        uid = sharedPreferences.getString("uid", "");
        point = sharedPreferences.getInt("point", 0);
        name = sharedPreferences.getString("name", "");
        message = sharedPreferences.getString("message", "");


        signout = findViewById(R.id.imageButton_signout);
        signout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editor.clear();
                editor.apply();
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        });
        scoremessage = (TextView) findViewById(R.id.scoremessage);
        messageWLD = findViewById(R.id.messageWLD);
        messagepoint = findViewById(R.id.messagepoint);
        messagepoint.setText("point:" + point);
        messageeditButton = findViewById(R.id.messageedit);
        messageoutputText = findViewById(R.id.textmessage);
        messageoutputText.setText(message);
        nameButton = findViewById(R.id.nameedit);
        namemessage = findViewById(R.id.editname);
        namemessage.setText(name);
        namemessage.setEnabled(false);
        namemessage.setBackgroundTintList(ColorStateList.valueOf(Color.TRANSPARENT));
        winrate = findViewById(R.id.winrate);

        ogurl = sharedPreferences.getString("url","");
        id= sharedPreferences.getString("ID","");
        messagepoint.setText("connecting...");

        String url = geturl("getuserdata", new String[]{"id", id});

        System.out.println(url);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                //output.setText(response);
                String[] parts = response.split("&");
                messagepoint.setText("第 "+parts[0]+" 名");
                messageWLD.setText("W:"+parts[1]+" L:"+parts[2]+" D:" +parts[3]);
                int userwin = Integer.parseInt(parts[1]);
                int userlose = Integer.parseInt(parts[2]);

                String winword = "勝率 :  ";

                if((userwin+userlose==0)){
                    winrate.setText(winword+("50%"));
                }
                else{
                    float winratefloat = (float)userwin / ((float)userlose+(float)userwin);
                    String winrateString = String.format("%.0f%%", winratefloat*100);
                    winrate.setText(winword+(winrateString));
                }

                scoremessage.setText( "score:" + parts[4]);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //output.setText("net error!");
                messageWLD.setText("資料庫連接出現問題!");
                System.out.println("===========勝率區出現問題==========");
            }

        });

        RequestQueue queue = Volley.newRequestQueue(MainActivityedit.this);
        queue.add(stringRequest);


        nameButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (nameeditable) {
                    namemessage.setEnabled(false);
                    namemessage.setBackgroundTintList(ColorStateList.valueOf(Color.TRANSPARENT));
                    if (namemessage.getText().toString().length() == 0) {
                        namemessage.setText(name);
                    } else {
                        name = namemessage.getText().toString();
                        database.child(uid).child("name").setValue(name);
                        editor.putString("name",name);
                        editor.apply();

                        String url = geturl("setname", new String[]{"id",id,"name",name});
                        System.out.println(url);
                        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {


                            }
                        }, new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                //output.setText("net error!");
                                System.out.println("===========名字修改區出現問題==========");
                            }

                        });

                        RequestQueue queue = Volley.newRequestQueue(MainActivityedit.this);
                        queue.add(stringRequest);



                    }
                } else {
                    namemessage.setText("");
                    namemessage.setHint(name);
                    namemessage.setEnabled(true);
                    namemessage.setBackgroundTintList(ColorStateList.valueOf(Color.WHITE));
                    namemessage.requestFocus(); // 設置焦點到 namemessage
                    namemessage.setSelection(namemessage.getText().length()); // 選擇 namemessage 中的文本
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.showSoftInput(namemessage, InputMethodManager.SHOW_IMPLICIT); // 顯示鍵盤
                }
                nameeditable = !nameeditable;

            }
        });

        namemessage.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    nameButton.performClick();
                    return true;
                }
                return false;
            }
        });

        messageeditButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showEditDialog();
            }
        });

        ImageView back = (ImageView) findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        imagephoto = findViewById(R.id.imagephoto);
        show_image();
        imagephoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.setType("image/*");
                startActivityForResult(intent, PICK_IMAGE_REQUEST);
            }
        });
    }

    private void showEditDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("請輸入訊息:");

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        input.setLines(5);
        input.setMaxLines(10);
        input.setGravity(Gravity.START | Gravity.TOP);
        input.setText(messageoutputText.getText().toString());

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(48, 0, 48, 0);
        input.setLayoutParams(lp);

        builder.setView(input);

        builder.setPositiveButton("確定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String text = input.getText().toString();
                messageoutputText.setText(text);
                database.child(uid).child("message").setValue(text);
                editor.putString("message",text);
                editor.apply();

                String url = geturl("setmessage", new String[]{"id",id,"message",text});
                System.out.println(url);
                StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {


                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //output.setText("net error!");
                        System.out.println("===========訊息修改區出現問題==========");
                    }

                });

                RequestQueue queue = Volley.newRequestQueue(MainActivityedit.this);
                queue.add(stringRequest);
            }
        });

        builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.setNeutralButton("清除文字", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                messageoutputText.setText("");

                database.child(uid).child("message").setValue("");

                String url = geturl("setmessage", new String[]{"id",id,"message","這人使用了清除按鈕"});
                System.out.println(url);
                StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {


                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //output.setText("net error!");
                        System.out.println("===========訊息修改區出現問題==========");
                    }

                });

                RequestQueue queue = Volley.newRequestQueue(MainActivityedit.this);
                queue.add(stringRequest);
            }
        });

        builder.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            StorageReference imageRef = FirebaseStorage.getInstance().getReference().child(uid).child("image.png");
                try {
                    // 讀取原始圖片
                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), uri);

                    // 計算壓縮比例，以實現圖片大小小於 300*300
                    int width = bitmap.getWidth();
                    int height = bitmap.getHeight();
                    int maxSize = Math.max(width, height);
                    float ratio = maxSize / 400.0f;

                    // 調整圖片大小，寬高比保持不變
                    int newWidth = (int) (width / ratio);
                    int newHeight = (int) (height / ratio);
                    Bitmap resizedBitmap = Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, true);

                    // 壓縮圖片，將品質設為70%
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    resizedBitmap.compress(Bitmap.CompressFormat.PNG, 70, baos);
                    byte[] bytes = baos.toByteArray();

                    // 上傳圖片，bytes是壓縮後的圖片數據
                    UploadTask uploadTask = imageRef.putBytes(bytes);
                    uploadTask.addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            // 上傳成功
                            Toast.makeText(MainActivityedit.this, "update success", Toast.LENGTH_SHORT).show();
                            try {
                                File file = new File(getFilesDir(), "image.png");
                                FileOutputStream fos = new FileOutputStream(file);
                                resizedBitmap.compress(Bitmap.CompressFormat.PNG, 70, fos);
                                fos.flush();
                                fos.close();
                                Log.i("TAG", "File saved successfully.");
                            } catch (IOException e) {
                                throw new RuntimeException(e);
                            }

                            // 讀取圖片並顯示在ImageView中
                            imagephoto.setImageBitmap(resizedBitmap);
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception exception) {
                            // 上傳失敗
                            Toast.makeText(MainActivityedit.this, "update fail", Toast.LENGTH_SHORT).show();
                        }
                    });
                } catch (IOException e) {
                    e.printStackTrace();
                }
        }
    }

    public void show_image() {
        String fileName = "image.png";
        File file = new File(getFilesDir(), fileName);
        if (file.exists()) {
            Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
            imagephoto.setImageBitmap(bitmap);
        } else {
            Log.d("image", "file no exists");
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        show_image();
    }

    private String geturl(String action, String[] input) {
        String outurl = ogurl + "?action=" + action;
        for (int i = 0; i < input.length; i += 2) {
            outurl = outurl + "&" + input[i] + "=" + input[i + 1];
        }

        return outurl;
    }
}