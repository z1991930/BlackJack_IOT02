package com.example.ex_4;

//import android.app.Dialog;
//import android.content.Context;
//import android.content.DialogInterface;
//import android.graphics.Color;
//import android.graphics.drawable.ColorDrawable;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Arrays;
//import androidx.fragment.app.FragmentManager;
//import androidx.fragment.app.FragmentPagerAdapter;

public class MainActivityshop extends AppCompatActivity {

    private View testbutton;
    private Button okButton;
    private boolean ispressok = false;

    private TextView item_text;
    private int point,card_used,table_used;
    private String uid,card_list,table_list,ogurl,id;

    private MySharedViewModel sharedViewModel;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    private LinearLayout back;
    protected DatabaseReference uref = FirebaseDatabase.getInstance().getReference().child("userinfo");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mainshop);

        sharedPreferences = getSharedPreferences("my_prefs", Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
        uid =  sharedPreferences.getString("uid","");
        point = sharedPreferences.getInt("point",0);
        card_used = sharedPreferences.getInt("card_used",0);
        table_used = sharedPreferences.getInt("table_used",0);
        card_list = sharedPreferences.getString("card_list","");
        table_list = sharedPreferences.getString("table_list","");
        ogurl = sharedPreferences.getString("url","");
        id= sharedPreferences.getString("ID","");

//        editor.putString("card_list", card_list);
//        editor.putString("table_list", table_list);
//        editor.putInt("card_used", card_used);
//        editor.putInt("table_used", table_used);

        //useratable = sharedPreferences.getInt("")
//        String card_list = snapshot.child("card_list").getValue(String.class);
//        String table_list = snapshot.child("table_list").getValue(String.class);
//        int card_used = snapshot.child("card_used").getValue(Integer.class);
//        int table_used = snapshot.child("table_used").getValue(Integer.class);
        //firebase Realtime Database root:/userinfo/uid
        DatabaseReference uidref =  uref.child(uid);
//        uidref.addListenerForSingleValueEvent(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                point = snapshot.child("point").getValue(Integer.class);
//                card_list = snapshot.child("card_list").getValue(String.class);
//                card_used = snapshot.child("card_used").getValue(Integer.class);
//                table_list = snapshot.child("table_list").getValue(String.class);
//                table_used = snapshot.child("table_used").getValue(Integer.class);
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });
        ////firebase Realtime Database root:/userinfo/uid


        sharedViewModel = new ViewModelProvider(this).get(MySharedViewModel.class);

        // 設置usermoney參數的值
        sharedViewModel.setUserMoney(point);
        sharedViewModel.setUseruseratable((char)table_used);
        sharedViewModel.setUseruseracardback((char)card_used);
        sharedViewModel.setUseruserhcardback(card_list);
        sharedViewModel.setUseruserhtable(table_list);


        // 建立Pager Adapter
        InnerPagerAdapter pagerAdapter = new InnerPagerAdapter(this);

        ViewPager2 viewPager = findViewById(R.id.viewPager);
        viewPager.setAdapter(pagerAdapter);

        TabLayout tabLayout = findViewById(R.id.tabLayout);
        new TabLayoutMediator(tabLayout, viewPager,
                (tab, position) -> tab.setText(pagerAdapter.getPageTitle(position))
        ).attach();


        sharedViewModel.getUserMoney().observe(this, new Observer<Integer>() {
            @Override
            public void onChanged(Integer money) {
                // 更新UI
                TextView curmoney = findViewById(R.id.curmoney);
                uidref.child("point").setValue(money);
                editor.putInt("point",money);
                editor.apply();
                curmoney.setText("擁有點數: "+money+"p");

                String url = geturl("setcoin", new String[]{"id",id,"coin",""+money});
                System.out.println(url);
                StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error){
                        System.out.println("金錢變更錯誤!");
                    }

                });

                RequestQueue queue = Volley.newRequestQueue(MainActivityshop.this);
                queue.add(stringRequest);

            }
        });

        sharedViewModel.getuseracardback().observe(this, new Observer<Character>() {
            @Override
            public void onChanged(Character character) {
                uidref.child("card_used").setValue((int)character);
                editor.putInt("card_used",(int)character);
                editor.apply();

                String url = geturl("setaback", new String[]{"id",id,"back",character+""});
                System.out.println(url);
                StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error){
                        System.out.println("當前卡背變更錯誤!");
                    }

                });

                RequestQueue queue = Volley.newRequestQueue(MainActivityshop.this);
                queue.add(stringRequest);
            }
        });

        sharedViewModel.getuseratable().observe(this, new Observer<Character>() {
            @Override
            public void onChanged(Character character) {
                uidref.child("table_used").setValue((int)character);
                editor.putInt("table_used",(int)character);
                editor.apply();

                String url = geturl("setatable", new String[]{"id",id,"table",character+""});
                System.out.println(url);
                StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error){
                        System.out.println("當前桌布變更錯誤!");
                    }

                });

                RequestQueue queue = Volley.newRequestQueue(MainActivityshop.this);
                queue.add(stringRequest);
            }
        });

        sharedViewModel.getuserhtable().observe(this, new Observer<String>() {
            @Override
            public void onChanged(String s) {
                char[] charArray = s.toCharArray();
                Arrays.sort(charArray);
                String sortedStr = new String(charArray);

                uidref.child("table_list").setValue(sortedStr);
                editor.putString("table_list",sortedStr);
                editor.apply();

                String url = geturl("sethtable", new String[]{"id",id,"table",sortedStr});
                System.out.println(url);
                StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error){
                        System.out.println("擁有桌布變更錯誤!");
                    }

                });

                RequestQueue queue = Volley.newRequestQueue(MainActivityshop.this);
                queue.add(stringRequest);
            }
        });

        sharedViewModel.getuserhcardback().observe(this, new Observer<String>() {
            @Override
            public void onChanged(String s) {
                char[] charArray = s.toCharArray();
                Arrays.sort(charArray);
                String sortedStr = new String(charArray);

                uidref.child("card_list").setValue(sortedStr);
                editor.putString("card_list",sortedStr);
                editor.apply();

                String url = geturl("sethback", new String[]{"id",id,"back",sortedStr});
                System.out.println(url);
                StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error){
                        System.out.println("擁有卡背變更錯誤!");
                    }

                });

                RequestQueue queue = Volley.newRequestQueue(MainActivityshop.this);
                queue.add(stringRequest);
            }
        });

        back = (LinearLayout)findViewById(R.id.back);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        //testbutton = findViewById(R.id.testButton);

//        testbutton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//
//            }
//                dialog.setContentView(R.layout.custom_dialog);
//                final TextView message = dialog.findViewById(R.id.dialog_message);
//                final TextView title = dialog.findViewById(R.id.dialog_title);
//                final ImageView icardimage =  dialog.findViewById(R.id.item_image);
//
//                icardimage.setImageResource(R.drawable.p5);
//
//                Context context = getApplicationContext();
//                DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
//                float dpWidth = displayMetrics.widthPixels;
//                float dpHeight = displayMetrics.heightPixels;
//
//                ConstraintLayout dialogLayout = dialog.findViewById(R.id.diglog);
//                ViewGroup.LayoutParams params = dialogLayout.getLayoutParams();
//                params.width = (int) (dpWidth * 0.8);
//                params.height = (int) (dpHeight * 0.5);
//                dialogLayout.setLayoutParams(params);
//
//
//                title.setText("星光");
//                message.setText("現有 8100 → 購買後 7500");
//
//                Button okButton = dialog.findViewById(R.id.dialog_ok_button);
//                okButton.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View v) {
//                        Toast.makeText(getApplicationContext(), "成功!", Toast.LENGTH_SHORT).show();
//                        dialog.dismiss();
//                    }
//                });
//
//                Button calcelButton = dialog.findViewById(R.id.dialog_calcelbutton);
//                calcelButton.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View v) {
//                        Toast.makeText(getApplicationContext(), "取消!", Toast.LENGTH_SHORT).show();
//                        dialog.dismiss();
//                    }
//                });
//
//                dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
//                    @Override
//                    public void onCancel(DialogInterface dialog) {
//                        Toast.makeText(getApplicationContext(), "失敗", Toast.LENGTH_SHORT).show();
//                    }
//                });
//
//                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
//                dialog.getWindow().setDimAmount(0.0f);
//                dialog.show();
//            }
//        });
        // 建立 Dialog


    }

    public class InnerPagerAdapter extends FragmentStateAdapter {

        public InnerPagerAdapter(@NonNull FragmentActivity fragmentActivity) {
            super(fragmentActivity);
        }

        @NonNull
        @Override
        public Fragment createFragment(int position) {
            Fragment fragment = null;

            // 根據目前頁面的編號，傳回對應的fragment物件
            switch (position) {
                case 0:
                    fragment = new FirstFragment();
                    break;
                case 1:
                    fragment = new SecondFragment();
                    ((SecondFragment) fragment).setSharedViewModel(sharedViewModel);
                    break;
                case 2:
                    fragment = new ThirdFragment();
                    break;
            }

            return fragment;
        }

        @Override
        public int getItemCount() {
            // 傳回頁面的總數
            return 3;
        }

        @Nullable
        public CharSequence getPageTitle(int position) {
            switch (position) {
                case 0:
                    return "點數";
                case 1:
                    return "卡背";
                case 2:
                    return "桌布";
                default:
                    return null;
            }
        }
    }

    private String geturl(String action, String[] input){
        String outurl = ogurl + "?action=" + action;
        for ( int i = 0; i < input.length ; i+=2 ){
            outurl = outurl + "&" + input[i] + "=" + input[i+1];
        }

        return outurl;
    }

}
