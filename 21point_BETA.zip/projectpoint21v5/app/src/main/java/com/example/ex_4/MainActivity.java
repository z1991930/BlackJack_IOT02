package com.example.ex_4;

import static android.service.controls.ControlsProviderService.TAG;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.text.Layout;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.concurrent.Executor;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainActivity extends AppCompatActivity implements View.OnTouchListener {

    private final String version_code = "1.2.1";
    private boolean version_is_same;
    private ImageButton login, register, buttonlogin1, buttonnext;
    private EditText editTextEmail1, editTextPassword1;
    private TextView dialogCancel, dialogCancel2;
    private EditText editTextEmail2, editTextPassword2, editTextPassword3, editTextName;
    private FirebaseAuth mAuth;
    private ProgressBar progressBar;
    private ImageView IV_tap;
    private Animation animation;

    DatabaseReference database = FirebaseDatabase.getInstance().getReference();
    String uid, ogurl;
    DatabaseReference udata = database.child("userinfo");
    FirebaseStorage storage = FirebaseStorage.getInstance();
    StorageReference storageRef = storage.getReference();
    private ImageView ImageView_photo;
    StorageReference userRef;
    StorageReference imageRef;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        login = (ImageButton) findViewById(R.id.Ibtn_login);
        register = (ImageButton) findViewById(R.id.Ibtn_register);
        login.setVisibility(View.INVISIBLE);
        register.setVisibility(View.INVISIBLE);
        IV_tap = findViewById(R.id.IV_tap);
        sharedPreferences = getSharedPreferences("my_prefs", Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
        database.child("url").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                ogurl = snapshot.getValue(String.class);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        //初始化 FirebaseAuth 實例
        mAuth = FirebaseAuth.getInstance();
        login.setOnClickListener(new View.OnClickListener() {
                                     @Override
                                     public void onClick(View v) {
                                         Dialog mybuilder = new Dialog(MainActivity.this);
                                         mybuilder.setContentView(R.layout.dialoglogin);
                                         editTextEmail1 = (EditText) mybuilder.findViewById(R.id.editTextEmail);
                                         editTextPassword1 = (EditText) mybuilder.findViewById(R.id.editTextPassword);
                                         buttonlogin1 = mybuilder.findViewById(R.id.Ibtn_login_next);

                                         buttonlogin1.setOnClickListener(new View.OnClickListener() {
                                             @Override
                                             public void onClick(View v) {
                                                 try {
                                                     String email = editTextEmail1.getText().toString();
                                                     String password = editTextPassword1.getText().toString();
                                                     // 認證使用者
                                                     mAuth.signInWithEmailAndPassword(email, password)
                                                             .addOnCompleteListener(MainActivity.this, new OnCompleteListener<AuthResult>() {
                                                                 @Override
                                                                 public void onComplete(@NonNull Task<AuthResult> task) {
                                                                     if (task.isSuccessful()) {
                                                                         FirebaseUser user = mAuth.getCurrentUser();
                                                                         uid = user.getUid();
                                                                         //確認User是否通過認證
                                                                         if (user != null && user.isEmailVerified()) {
                                                                             editor.putBoolean("is_login", true);
                                                                             editor.putString("uid", uid);
                                                                             editor.apply();
                                                                             IV_tap.startAnimation(animation);
                                                                             IV_tap.setVisibility(View.VISIBLE);
                                                                             login.setVisibility(View.INVISIBLE);
                                                                             register.setVisibility(View.INVISIBLE);
                                                                             mybuilder.dismiss();
                                                                             signin();
                                                                         } else {
                                                                             // 登錄成功，但用戶未通過電子郵件驗證
                                                                             Toast.makeText(MainActivity.this, "請至註冊信箱收信", Toast.LENGTH_SHORT).show();
                                                                         }

                                                                     } else {
                                                                         // 登入失敗，顯示錯誤信息
                                                                         Log.w("TAG", "signInWithEmail:failure", task.getException());
                                                                         Toast.makeText(MainActivity.this, "登入失敗，請檢查帳號密碼是否正確", Toast.LENGTH_SHORT).show();
                                                                         editTextPassword1.setText("");
                                                                     }
                                                                 }
                                                             });
                                                 } catch (Exception e) {
                                                     Toast.makeText(MainActivity.this, "請輸入完整資料", Toast.LENGTH_SHORT).show();
                                                 }
                                             }
                                         });
                                         dialogCancel = mybuilder.findViewById(R.id.TV_cancel);
                                         dialogCancel.setOnClickListener(new View.OnClickListener() {
                                             @Override
                                             public void onClick(View v) {
                                                 mybuilder.dismiss();
                                             }
                                         });
                                         // 設置Dialog的寬度為使用者螢幕寬度的80%
                                         WindowManager.LayoutParams params = mybuilder.getWindow().getAttributes();
                                         DisplayMetrics metrics = getResources().getDisplayMetrics();
                                         int screenWidth = metrics.widthPixels;
                                         params.width = (int) (screenWidth * 0.8);
                                         mybuilder.getWindow().setAttributes(params);
                                         mybuilder.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                                         mybuilder.show();

                                     }
                                 }
        );

        register.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            Dialog mybuilder2 = new Dialog(MainActivity.this);
                                            mybuilder2.setContentView(R.layout.diglogregeister);
                                            EditText editTextName = mybuilder2.findViewById(R.id.editTextName);
                                            EditText editTextEmail2 = (EditText) mybuilder2.findViewById(R.id.editTextemail2);
                                            EditText editTextPassword2 = (EditText) mybuilder2.findViewById(R.id.editTextPassword2);
                                            EditText editTextPassword3 = (EditText) mybuilder2.findViewById(R.id.editTextPassword3);
                                            buttonnext = mybuilder2.findViewById(R.id.Ibtn_register_next);

                                            buttonnext.setOnClickListener(new View.OnClickListener() {
                                                @Override
                                                public void onClick(View v) {
                                                    try {
                                                        String name = editTextName.getText().toString();
                                                        String email = editTextEmail2.getText().toString();
                                                        String passwd = editTextPassword2.getText().toString();
                                                        //禁止特殊字元名稱
                                                        if (containsSpecialChar(name)) {
                                                            // 包含特殊字符
                                                        } else {
                                                            // 不包含特殊字符

                                                            if (passwd.equals(editTextPassword3.getText().toString())) {
                                                                mAuth.createUserWithEmailAndPassword(email, passwd).addOnCompleteListener(MainActivity.this, new OnCompleteListener<AuthResult>() {
                                                                    @Override
                                                                    public void onComplete(@NonNull Task<AuthResult> task) {
                                                                        if (task.isSuccessful()) {
                                                                            // 註冊成功
                                                                            Log.d("Email_OK", "createUserWithEmail:success");
                                                                            FirebaseUser user = mAuth.getCurrentUser();
                                                                            // 創建一個新的使用者節點
                                                                            uid = user.getUid();
                                                                            DatabaseReference userRef = database.child("userinfo").child(uid);

                                                                            // 在該節點中存儲使用者資訊，資料初始化
                                                                            userRef.child("email").setValue(email);
                                                                            userRef.child("name").setValue(name);
                                                                            userRef.child("passwd").setValue(passwd);
                                                                            userRef.child("point").setValue(15000);
                                                                            userRef.child("card_list").setValue("A");
                                                                            userRef.child("table_list").setValue("A");
                                                                            userRef.child("card_used").setValue(65);
                                                                            userRef.child("table_used").setValue(65);
                                                                            userRef.child("score").setValue(0);
                                                                            userRef.child("message").setValue("他還什麼都沒寫");

                                                                            String url = geturl("create", new String[]{"account", email, "uid", uid, "name", name, "coin", "20000"});
                                                                            // String url = geturl("addwin", new String[]{"id","4"});
                                                                            //String url = geturl("adddraw", new String[]{"id","4"});

                                                                            //String url = geturl("addhback", new String[]{"id","4","back","D"}); // error S->C 錯誤
                                                                            // String url = geturl("addscore", new String[]{"id","5","number","50"}); //error 參數錯誤
                                                                            System.out.println(url);
                                                                            StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                                                                                @Override
                                                                                public void onResponse(String response) {
                                                                                    //output.setText(response);

                                                                                }
                                                                            }, new Response.ErrorListener() {
                                                                                @Override
                                                                                public void onErrorResponse(VolleyError error) {
                                                                                    //output.setText("net error!");
                                                                                }

                                                                            });

                                                                            RequestQueue queue = Volley.newRequestQueue(MainActivity.this);
                                                                            queue.add(stringRequest);

                                                                            user.sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                                                                                @Override
                                                                                public void onComplete(@NonNull Task<Void> task) {
                                                                                    if (task.isSuccessful()) {
                                                                                        // 驗證郵件發送成功
                                                                                        Toast.makeText(getApplicationContext(), "註冊信已發送至 " + mAuth.getCurrentUser().getEmail(), Toast.LENGTH_SHORT).show();
                                                                                        IV_tap.setVisibility(View.VISIBLE);
                                                                                        login.setVisibility(View.INVISIBLE);
                                                                                        register.setVisibility(View.INVISIBLE);
                                                                                        IV_tap.startAnimation(animation);
                                                                                        mybuilder2.dismiss();

                                                                                        Dialog finish = new Dialog(MainActivity.this);
                                                                                        finish.setContentView(R.layout.dialog_regeister_finish);
                                                                                        // 設置Dialog的寬度為使用者螢幕寬度的80%
                                                                                        WindowManager.LayoutParams params = finish.getWindow().getAttributes();
                                                                                        DisplayMetrics metrics = getResources().getDisplayMetrics();
                                                                                        int screenWidth = metrics.widthPixels;
                                                                                        params.width = (int) (screenWidth * 0.8);
                                                                                        finish.getWindow().setAttributes(params);
                                                                                        finish.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                                                                                        finish.show();

                                                                                        new Handler().postDelayed(new Runnable() {
                                                                                            @Override
                                                                                            public void run() {
                                                                                                finish.dismiss();
                                                                                            }
                                                                                        }, 3000);

                                                                                    } else {
                                                                                        // 驗證郵件發送失敗
                                                                                        Toast.makeText(getApplicationContext(), "Failed to send verification email.", Toast.LENGTH_SHORT).show();
                                                                                    }
                                                                                }
                                                                            });
                                                                        } else {
                                                                            // 註冊失敗
                                                                            Exception e = task.getException();
                                                                            Log.w(TAG, "createUserWithEmail:failure", e);
                                                                            if (e instanceof FirebaseAuthUserCollisionException) {
                                                                                // 該使用者已經存在
                                                                                Toast.makeText(MainActivity.this, "該使用者已經存在", Toast.LENGTH_SHORT).show();
                                                                            } else {
                                                                                // 其他錯誤
                                                                                Toast.makeText(MainActivity.this, "註冊失敗，請詢問管理者", Toast.LENGTH_SHORT).show();
                                                                            }
                                                                        }
                                                                    }
                                                                });
                                                            }
                                                        }
                                                    } catch (Exception e) {
                                                        editTextName.setHint("請輸入名稱");
                                                        editTextEmail2.setHint("請輸入E-mail");
                                                        editTextPassword2.setHint("請輸入密碼");
                                                        editTextPassword3.setHint("請再次輸入密碼");
                                                        Toast.makeText(MainActivity.this, "請輸入完整資料", Toast.LENGTH_SHORT).show();
                                                    }

                                                }
                                            });
                                            dialogCancel2 = mybuilder2.findViewById(R.id.TV_cancel2);
                                            dialogCancel2.setOnClickListener(new View.OnClickListener() {
                                                @Override
                                                public void onClick(View v) {
                                                    mybuilder2.dismiss();
                                                }
                                            });
                                            // 設置Dialog的寬度為使用者螢幕寬度的80%
                                            WindowManager.LayoutParams params = mybuilder2.getWindow().getAttributes();
                                            DisplayMetrics metrics = getResources().getDisplayMetrics();
                                            int screenWidth = metrics.widthPixels;
                                            params.width = (int) (screenWidth * 0.8);
                                            mybuilder2.getWindow().setAttributes(params);
                                            mybuilder2.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                                            mybuilder2.show();

                                        }
                                    }
        );


        // 設置一個無限循環的閃爍動畫
        animation = new AlphaAnimation(1, 0);
        animation.setDuration(500);
        animation.setInterpolator(new LinearInterpolator());
        animation.setRepeatCount(Animation.INFINITE);
        animation.setRepeatMode(Animation.REVERSE);

        // 開始閃爍動畫
        IV_tap.startAnimation(animation);

        // 設置觸碰監聽器
        IV_tap.setOnTouchListener(this);

//        Dialog loading = new Dialog(MainActivity.this);
//        loading.setContentView(R.layout.dialog_loading);
//        Window window = loading.getWindow();
//        if (window != null) {
//            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
//        }
//        progressBar = loading.findViewById(R.id.progressBar);
//        loading.show();
        loading loading = new loading(MainActivity.this);
        //讀取版本內容
        database.child("version_code").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String ver_code_new = snapshot.getValue(String.class);
                version_is_same = ver_code_new.equals(version_code);
                Log.d(TAG, "onDataChange: "+ver_code_new);
                Log.d(TAG, "Boolean "+version_is_same);
//                loading.dismiss();
                loading.finish();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    public void createimage(String fileName, File content) {
        try {
            FileOutputStream outputStream = openFileOutput(fileName, Context.MODE_PRIVATE);
            InputStream inputStream = new FileInputStream(content);
            byte[] buffer = new byte[1024];
            int length;
            while ((length = inputStream.read(buffer)) > 0) {
                outputStream.write(buffer, 0, length);
            }
            inputStream.close();
            outputStream.close();
            Log.i("TAG", "File saved successfully.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void waitimagetrans(FileDownloadTask downloadTask, String filename, File localfile) {
        // 監聽下載進度
        downloadTask.addOnProgressListener(new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
            @Override
            public void onProgress(@NonNull FileDownloadTask.TaskSnapshot taskSnapshot) {
                double progress = (100.0 * taskSnapshot.getBytesTransferred()) / taskSnapshot.getTotalByteCount();
            }
        });
        // 開始下載
        downloadTask.addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                // 下載成功，進行轉檔儲存
                createimage(filename, localfile);
                Intent it = new Intent(MainActivity.this, homepage.class);
                startActivity(it);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {
                // 下載失敗，輸出錯誤訊息
                Log.e("TAG", exception.getMessage());
                FileDownloadTask downloadTask = storageRef.child("userdefault.jpg").getFile(localfile);
                waitimagetrans(downloadTask, filename, localfile);
            }
        });

    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        // 在觸碰時停止閃爍動畫
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            if (version_is_same) {
                IV_tap.clearAnimation();
                signin();
            } else {
                Toast.makeText(this, "版本不符，請更新!!", Toast.LENGTH_LONG).show();
                update();
            }

        }
        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        IV_tap.startAnimation(animation);
    }

    private String geturl(String action, String[] input) {
        String outurl = ogurl + "?action=" + action;
        for (int i = 0; i < input.length; i += 2) {
            outurl = outurl + "&" + input[i] + "=" + input[i + 1];
        }

        return outurl;
    }

    public boolean containsSpecialChar(String str) {
        String regex = "[!@#\\$%\\^&\\*\\(\\)_\\+\\=\\{\\}\\[\\]\\|\\\\;:\"<>,\\.\\?/]";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(str);
        return matcher.find();
    }

    public void signin() {
        if (sharedPreferences.getBoolean("is_login", false)) {
            Log.i("is_login", "true");
//            Dialog loading = new Dialog(MainActivity.this);
//            loading.setContentView(R.layout.dialog_loading);
//            Window window = loading.getWindow();
//            if (window != null) {
//                window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
//            }
//            progressBar = loading.findViewById(R.id.progressBar);
//            loading.show();
            loading loading = new loading(MainActivity.this);
            // 到firebase抓資料，並將下個頁面需要立即顯示的資料放入sharePreference
            uid = sharedPreferences.getString("uid", "");
            udata.child(uid).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    int point = snapshot.child("point").getValue(Integer.class);
                    String name = snapshot.child("name").getValue(String.class);
                    String card_list = snapshot.child("card_list").getValue(String.class);
                    String table_list = snapshot.child("table_list").getValue(String.class);
                    int card_used = snapshot.child("card_used").getValue(Integer.class);
                    int table_used = snapshot.child("table_used").getValue(Integer.class);
                    String message = snapshot.child("message").getValue(String.class);
                    Toast.makeText(MainActivity.this, "Welcome back " + name, Toast.LENGTH_SHORT).show();
                    //login =======================================================
                    String url = geturl("login", new String[]{"uid", uid});
                    //System.out.println(url);
                    StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            //output.setText(response);
                            String ID = response;
                            editor.putString("url", ogurl);
                            editor.putString("ID", ID);
                            editor.apply();
                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            //output.setText("net error!");
                        }

                    });

                    RequestQueue queue = Volley.newRequestQueue(MainActivity.this);
                    queue.add(stringRequest);

                    //用SharePreferences做資料共享
                    editor.putString("name", name);
                    editor.putInt("point", point);
                    editor.putString("card_list", card_list);
                    editor.putString("table_list", table_list);
                    editor.putInt("card_used", card_used);
                    editor.putInt("table_used", table_used);
                    editor.putString("message", message);
                    editor.apply();
                    try {
                        //開始下載圖片
                        userRef = storageRef.child(uid);
                        imageRef = userRef.child("image.png");
                        String fileName = "image.png";
                        File localFile = File.createTempFile("image", "png");
                        // 創建文件下載任務
                        FileDownloadTask downloadTask = imageRef.getFile(localFile);
                        waitimagetrans(downloadTask, fileName, localFile);
//                        loading.dismiss();
                        loading.finish();
                    } catch (IOException e) {
                        // 輸出錯誤訊息
                        e.printStackTrace();
                    }

                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Log.w("TAG", "Failed to read value.", error.toException());
                }
            });
        } else {
            Log.i("is_login", "false");
            IV_tap.setVisibility(View.GONE);
            login.setVisibility(View.VISIBLE);
            register.setVisibility(View.VISIBLE);
        }
    }

    public void update() {
        database.child("update").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String update = snapshot.getValue(String.class);
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(update));
                startActivity(intent);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}
