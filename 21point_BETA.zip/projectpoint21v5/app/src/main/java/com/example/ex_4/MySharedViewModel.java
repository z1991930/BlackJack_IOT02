package com.example.ex_4;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class MySharedViewModel extends ViewModel {

    private MutableLiveData<Integer> userMoney = new MutableLiveData<>();

    public MutableLiveData<Integer> getUserMoney() {
        return userMoney;
    }

    public void setUserMoney(Integer money) {
        userMoney.setValue(money);
    }

    private MutableLiveData<Character> useratable = new MutableLiveData<>();

    public MutableLiveData<Character> getuseratable() {
        return useratable;
    }

    public void setUseruseratable(Character atable) {
        useratable.setValue(atable);
    }

    private MutableLiveData<Character> useracardback = new MutableLiveData<>();

    public MutableLiveData<Character> getuseracardback() {
        return useracardback;
    }

    public void setUseruseracardback(Character acardback) {
        useracardback.setValue(acardback);
    }

    private MutableLiveData<String> userhtable = new MutableLiveData<>();

    public MutableLiveData<String> getuserhtable() {
        return userhtable;
    }

    public void setUseruserhtable(String htable) {
        userhtable.setValue(htable);
    }

    private MutableLiveData<String> userhcardback = new MutableLiveData<>();

    public MutableLiveData<String> getuserhcardback() {
        return userhcardback;
    }

    public void setUseruserhcardback(String hcardback) {
        userhcardback.setValue(hcardback);
    }
}
