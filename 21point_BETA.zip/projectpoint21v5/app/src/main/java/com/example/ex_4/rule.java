package com.example.ex_4;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

public class rule extends AppCompatActivity {

    private LinearLayout LinearLayout_rule;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rule);

        LinearLayout_rule =(LinearLayout) findViewById(R.id.LinearLayout_rule);
        LinearLayout_rule.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


    }


}